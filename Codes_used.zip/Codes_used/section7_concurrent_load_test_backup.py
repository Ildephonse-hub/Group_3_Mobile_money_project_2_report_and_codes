
# ============================================================
# 8. SYNCHRONIZED START-TIME SUPPORT
# ============================================================

class BarrierStartAction:
    """
    Pickleable barrier action for Windows multiprocessing.

    The class is defined at module level so that Windows
    multiprocessing with the spawn method can serialize it.
    """

    def __init__(self, shared_start_time):
        self.shared_start_time = shared_start_time

    def __call__(self):
        # Record one common start time when the barrier releases.
        self.shared_start_time.value = time.perf_counter()


def create_start_barrier(client_count, shared_start_time):
    """
    Create a barrier for all client processes plus the parent.

    Every client warms up first. The parent participates in
    the barrier, so the timed period starts only when all
    clients are ready.
    """

    return mp.Barrier(
        client_count + 1,
        action=BarrierStartAction(shared_start_time),
    )
