
from getpass import getpass
from neo4j import GraphDatabase

URI = "bolt://localhost:7687"
USER = "neo4j"

password = getpass("Neo4j password for neo4j: ")

driver = GraphDatabase.driver(
    URI,
    auth=(USER, password),
)

try:
    driver.verify_connectivity()
    print("\nNeo4j connection: OK")

    with driver.session(database="neo4j") as session:
        result = session.run("""
            SHOW PROCEDURES
            YIELD name
            WHERE name STARTS WITH 'apoc.'
            RETURN name
            ORDER BY name
            LIMIT 10
        """)

        procedures = [record["name"] for record in result]

        if procedures:
            print("\nAPOC procedures found:")
            for name in procedures:
                print(name)
        else:
            print("\nNo APOC procedures found.")

except Exception as exc:
    print("\nDiagnostic error:", exc)

finally:
    driver.close()
