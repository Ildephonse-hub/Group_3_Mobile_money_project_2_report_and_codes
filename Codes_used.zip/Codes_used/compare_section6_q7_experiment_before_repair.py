
"""
Section 6.1 — PostgreSQL vs Neo4j verification
Q1: Outgoing transfers during the review hour.
Q2: Daily transfer activity in September 2026.
Q3: Shared devices with overlapping usage intervals.
Q4: Ownership/device network reach.
Q5: Rapid onward payments.
Q6: Circular payments.

PostgreSQL: localhost:5433 / mobile_money_investigations
Neo4j: bolt://localhost:7687 / neo4j
"""

from datetime import date, datetime, time
from getpass import getpass
from zoneinfo import ZoneInfo

import psycopg
from neo4j import GraphDatabase


# ============================================================
# 1. CONFIGURATION
# ============================================================

PG_HOST = "localhost"
PG_PORT = 5433
PG_DATABASE = "mobile_money_investigations"
PG_USER = "postgres"

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_DATABASE = "neo4j"

TZ = ZoneInfo("Africa/Kigali")

CASES = (
    ("A", 998, 6),
    ("B", 147228, 13),
    ("C", 206978, 8),
    ("D", 237998, 6),
    ("E", 144228, 13),
    ("F", 203978, 8),
)

Q4_DEPTHS = (4, 6, 8, 10)


# ============================================================
# 2. POSTGRESQL QUERIES
# ============================================================

SQL_Q1 = """
SELECT
    COUNT(t.transfer_id),
    COALESCE(SUM(t.amount_rwf), 0)
FROM accounts a
LEFT JOIN transfers t
    ON t.sender_id = a.account_id
   AND t.occurred_at >= %s
   AND t.occurred_at < %s
WHERE a.account_id = %s
"""


SQL_Q2 = """
WITH days AS (
    SELECT generate_series(
        DATE '2026-09-01',
        DATE '2026-09-30',
        INTERVAL '1 day'
    )::date AS local_day
),
daily AS (
    SELECT
        (to_timestamp(occurred_at)
            AT TIME ZONE 'Africa/Kigali')::date AS local_day,
        COUNT(*) AS transfer_count,
        SUM(amount_rwf) AS total_rwf
    FROM transfers
    WHERE occurred_at >= %s
      AND occurred_at < %s
    GROUP BY 1
)
SELECT
    d.local_day::text,
    COALESCE(x.transfer_count, 0),
    COALESCE(x.total_rwf, 0)
FROM days d
LEFT JOIN daily x USING (local_day)
ORDER BY d.local_day
"""


SQL_Q3 = """
SELECT DISTINCT
    other.account_id,
    d.device_id,
    d.access_type,
    GREATEST(review.first_day, other.first_day),
    LEAST(review.last_day, other.last_day)
FROM account_devices review
JOIN account_devices other
    ON other.device_id = review.device_id
   AND other.account_id <> review.account_id
   AND review.first_day <= other.last_day
   AND other.first_day <= review.last_day
JOIN devices d ON d.device_id = review.device_id
WHERE review.account_id = %s
ORDER BY 1, 2, 3, 4, 5
"""


SQL_Q4 = """
WITH RECURSIVE edges(src, dst) AS (
    SELECT 'C:' || customer_id::text,
           'A:' || account_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'C:' || customer_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'D:' || device_id::text
    FROM account_devices

    UNION

    SELECT 'D:' || device_id::text,
           'A:' || account_id::text
    FROM account_devices
),
walk(node, depth) AS (
    SELECT 'A:' || %s::text, 0

    UNION

    SELECT e.dst, w.depth + 1
    FROM walk w
    JOIN edges e ON e.src = w.node
    WHERE w.depth < %s
),
reachable AS (
    SELECT DISTINCT
        split_part(node, ':', 2)::integer AS account_id
    FROM walk
    WHERE node LIKE 'A:%%'
      AND depth BETWEEN 1 AND %s
)
SELECT
    c.region,
    COUNT(DISTINCT a.account_id)
FROM reachable r
JOIN accounts a ON a.account_id = r.account_id
JOIN customers c ON c.customer_id = a.customer_id
WHERE a.account_id <> %s
GROUP BY c.region
ORDER BY c.region
"""


SQL_Q5 = """
SELECT
    ARRAY[t1.transfer_id, t2.transfer_id, t3.transfer_id],
    t3.receiver_id
FROM transfers t1
JOIN transfers t2 ON t2.sender_id = t1.receiver_id
JOIN transfers t3 ON t3.sender_id = t2.receiver_id
WHERE t1.sender_id = %s
  AND t1.occurred_at >= %s
  AND t1.occurred_at < %s

  AND t2.occurred_at > t1.occurred_at
  AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at
  AND t3.occurred_at <= t2.occurred_at + 600

  AND 100::bigint * t2.amount_rwf >= 90::bigint * t1.amount_rwf
  AND 100::bigint * t2.amount_rwf <= 105::bigint * t1.amount_rwf
  AND 100::bigint * t3.amount_rwf >= 90::bigint * t2.amount_rwf
  AND 100::bigint * t3.amount_rwf <= 105::bigint * t2.amount_rwf

  AND t1.sender_id <> t1.receiver_id
  AND t1.sender_id <> t2.receiver_id
  AND t1.sender_id <> t3.receiver_id
  AND t1.receiver_id <> t2.receiver_id
  AND t1.receiver_id <> t3.receiver_id
  AND t2.receiver_id <> t3.receiver_id
ORDER BY 1, 2
"""


# Q6: Build transfer sequences recursively.
# Each sequence starts at the review account during the review hour.
# All transfers must be within the hour and span <= 1800 seconds.
# The recursion stops when the starting account is reached again.
SQL_Q6 = """
WITH RECURSIVE paths AS (
    SELECT
        t.sender_id AS start_account,
        t.receiver_id AS current_account,
        ARRAY[t.transfer_id]::bigint[] AS transfer_ids,
        ARRAY[t.sender_id, t.receiver_id]::integer[] AS account_path,
        t.occurred_at AS first_time,
        t.occurred_at AS last_time,
        t.amount_rwf AS last_amount,
        1 AS transfer_count
    FROM transfers t
    WHERE t.sender_id = %s
      AND t.occurred_at >= %s
      AND t.occurred_at < %s

    UNION ALL

    SELECT
        p.start_account,
        t.receiver_id,
        p.transfer_ids || t.transfer_id,
        p.account_path || t.receiver_id,
        p.first_time,
        t.occurred_at,
        t.amount_rwf,
        p.transfer_count + 1
    FROM paths p
    JOIN transfers t
      ON t.sender_id = p.current_account
    WHERE p.current_account <> p.start_account
      AND p.transfer_count < 8

      AND t.occurred_at > p.last_time
      AND t.occurred_at < %s
      AND t.occurred_at - p.first_time <= 1800

      AND 100::bigint * t.amount_rwf
          >= 90::bigint * p.last_amount
      AND 100::bigint * t.amount_rwf
          <= 105::bigint * p.last_amount
)
SELECT
    transfer_ids,
    transfer_count
FROM paths
WHERE current_account = start_account
  AND transfer_count BETWEEN 3 AND 8
  AND last_time - first_time <= 1800
ORDER BY transfer_ids
"""


# ============================================================
# 3. NEO4J QUERIES
# ============================================================

CYPHER_Q1 = """
MATCH (a:Account {account_id: $account})
OPTIONAL MATCH (a)-[t:TRANSFER]->()
WHERE t.occurred_at >= $start_epoch
  AND t.occurred_at < $end_epoch
RETURN count(t), coalesce(sum(t.amount_rwf), 0)
"""


CYPHER_Q2 = """
MATCH ()-[t:TRANSFER]->()
WHERE t.occurred_at >= $start_epoch
  AND t.occurred_at < $end_epoch

WITH
    date(datetime({
        epochSeconds: t.occurred_at,
        timezone: "Africa/Kigali"
    })) AS local_day,
    count(t) AS transfer_count,
    sum(t.amount_rwf) AS total_rwf

RETURN
    toString(local_day) AS local_day,
    transfer_count,
    total_rwf
ORDER BY local_day
"""


CYPHER_Q3 = """
MATCH
    (review:Account {account_id: $account})
        -[r:USED_DEVICE]->(d:Device)
        <-[s:USED_DEVICE]-(other:Account)
WHERE other.account_id <> review.account_id
  AND r.first_day <= s.last_day
  AND s.first_day <= r.last_day
RETURN DISTINCT
    other.account_id AS other_account_id,
    d.device_id AS device_id,
    d.access_type AS access_type,
    CASE WHEN r.first_day > s.first_day
         THEN r.first_day ELSE s.first_day END AS overlap_start,
    CASE WHEN r.last_day < s.last_day
         THEN r.last_day ELSE s.last_day END AS overlap_end
ORDER BY other_account_id, device_id, access_type, overlap_start, overlap_end
"""

def cypher_q4(depth):
    return f"""
    MATCH
        (start:Account {{account_id: $account}})
        -[:OWNS|USED_DEVICE*1..{depth}]-
        (reachable:Account)
    WHERE reachable.account_id <> start.account_id
    WITH DISTINCT reachable
    MATCH (owner:Customer)-[:OWNS]->(reachable)
    RETURN owner.region, count(DISTINCT reachable.account_id)
    ORDER BY owner.region
    """


CYPHER_Q5 = """
MATCH
    (a:Account {account_id: $account})
        -[t1:TRANSFER]->(b:Account)
        -[t2:TRANSFER]->(c:Account)
        -[t3:TRANSFER]->(d:Account)
WHERE t1.occurred_at >= $start_epoch
  AND t1.occurred_at < $end_epoch

  AND t2.occurred_at > t1.occurred_at
  AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at
  AND t3.occurred_at <= t2.occurred_at + 600

  AND 100 * toInteger(t2.amount_rwf) >= 90 * toInteger(t1.amount_rwf)
  AND 100 * toInteger(t2.amount_rwf) <= 105 * toInteger(t1.amount_rwf)
  AND 100 * toInteger(t3.amount_rwf) >= 90 * toInteger(t2.amount_rwf)
  AND 100 * toInteger(t3.amount_rwf) <= 105 * toInteger(t2.amount_rwf)

  AND a.account_id <> b.account_id
  AND a.account_id <> c.account_id
  AND a.account_id <> d.account_id
  AND b.account_id <> c.account_id
  AND b.account_id <> d.account_id
  AND c.account_id <> d.account_id
RETURN
    [t1.transfer_id, t2.transfer_id, t3.transfer_id],
    d.account_id
ORDER BY 1, 2
"""


# Circular path: start and end at the review account.
# The first transfer must start during the review hour.
# All transfers are inside the hour, increasing in time,
# and the path must return for the first time at its final step.



CYPHER_Q6 = """
MATCH
    (start:Account {account_id: $account})
    -[rs:TRANSFER*3..8]->(start)

WHERE
    all(
        r IN rs
        WHERE r.occurred_at >= $start_epoch
          AND r.occurred_at < $end_epoch
    )

    AND rs[size(rs) - 1].occurred_at - rs[0].occurred_at <= 1800

    AND all(
        i IN range(0, size(rs) - 2)
        WHERE
            rs[i + 1].occurred_at > rs[i].occurred_at

            AND 100 * toInteger(rs[i + 1].amount_rwf)
                >= 90 * toInteger(rs[i].amount_rwf)

            AND 100 * toInteger(rs[i + 1].amount_rwf)
                <= 105 * toInteger(rs[i].amount_rwf)
    )

RETURN
    [r IN rs | r.transfer_id] AS transfer_ids,
    size(rs) AS transfer_count

ORDER BY transfer_ids
"""

# ============================================================
# 4. COMMON HELPERS
# ============================================================

def september_epoch_bounds():
    start = datetime.combine(
        date(2026, 9, 1), time(0, 0), tzinfo=TZ
    )
    end = datetime.combine(
        date(2026, 10, 1), time(0, 0), tzinfo=TZ
    )
    return int(start.timestamp()), int(end.timestamp())


def q1_epoch_bounds(day_number):
    d = date(2026, 9, day_number)
    start = datetime.combine(d, time(9, 45), tzinfo=TZ)
    end = datetime.combine(d, time(10, 45), tzinfo=TZ)
    return int(start.timestamp()), int(end.timestamp())


def run_pg(conn, query, params=()):
    with conn.cursor() as cur:
        cur.execute(query, params)
        return cur.fetchall()


def run_neo(session, query, params=None):
    return [
        record.data()
        for record in session.run(query, params or {})
    ]


def normalize(rows):
    result = []
    for row in rows:
        if isinstance(row, dict):
            row = tuple(row.values())
        else:
            row = tuple(row)

        values = []
        for value in row:
            if isinstance(value, (list, tuple)):
                value = tuple(value)
            values.append(value)

        result.append(tuple(values))
    return sorted(result, key=repr)


def compare(title, pg_rows, neo_rows):
    # Each engine's output is converted into a comparable format.
    p = normalize(pg_rows)
    n = normalize(neo_rows)
    passed = p == n

    print("\n" + title)
    print("  PostgreSQL rows:", len(pg_rows))
    print("  Neo4j rows:     ", len(neo_rows))
    print("  RESULT:", "PASS" if passed else "FAIL")

    if not passed:
        print("  PostgreSQL:", p)
        print("  Neo4j:     ", n)

    return passed


# ============================================================
# 5. Q1
# ============================================================

def compare_q1(pg, neo):
    print("\n" + "=" * 72)
    print("Q1 — OUTGOING TRANSFER ACTIVITY")
    print("=" * 72)

    passed = 0
    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)
        p = run_pg(pg, SQL_Q1, (start, end, account))
        n = run_neo(
            neo, CYPHER_Q1,
            {"account": account, "start_epoch": start, "end_epoch": end}
        )
        n = [(r["count(t)"], r["coalesce(sum(t.amount_rwf), 0)"]) for r in n]

        if compare(f"Q1 Case {case} — account {account}", p, n):
            passed += 1

    print(f"\nQ1 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 6. Q2
# ============================================================

def compare_q2(pg, neo):
    print("\n" + "=" * 72)
    print("Q2 — DAILY TRANSFER ACTIVITY")
    print("=" * 72)

    start, end = september_epoch_bounds()
    p = run_pg(pg, SQL_Q2, (start, end))
    n = run_neo(
        neo, CYPHER_Q2,
        {"start_epoch": start, "end_epoch": end}
    )

    daily_by_date = {
        r["local_day"]: (
            int(r["transfer_count"]),
            int(r["total_rwf"] or 0),
        )
        for r in n
    }

    n = [
        (
            f"2026-09-{day:02d}",
            daily_by_date.get(f"2026-09-{day:02d}", (0, 0))[0],
            daily_by_date.get(f"2026-09-{day:02d}", (0, 0))[1],
        )
        for day in range(1, 31)
    ]

    ok = compare("Q2 — all 30 September dates", p, n)

    if ok:
        print("\nSeptember transfer count:", sum(int(r[1]) for r in p))
        print("September total RWF:     ", sum(int(r[2]) for r in p))

    return ok
# ============================================================
# 7. Q3
# ============================================================

def compare_q3(pg, neo):
    print("\n" + "=" * 72)
    print("Q3 — SHARED DEVICES AND OVERLAPPING USAGE")
    print("=" * 72)

    passed = 0
    for case, account, _day in CASES:
        p = run_pg(pg, SQL_Q3, (account,))
        n = run_neo(neo, CYPHER_Q3, {"account": account})

        n = [
            (
                r["other_account_id"],
                r["device_id"],
                r["access_type"],
                r["overlap_start"],
                r["overlap_end"],
            )
            for r in n
        ]

        if compare(f"Q3 Case {case} — account {account}", p, n):
            passed += 1

    print(f"\nQ3 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 8. Q4
# ============================================================

def compare_q4(pg, neo):
    print("\n" + "=" * 72)
    print("Q4 — OWNERSHIP AND DEVICE NETWORK REACH")
    print("=" * 72)

    passed = 0
    total = 0

    for case, account, _day in CASES:
        for depth in Q4_DEPTHS:
            total += 1
            p = run_pg(pg, SQL_Q4, (account, depth, depth, account))
            n = run_neo(neo, cypher_q4(depth), {"account": account})
            n = [(r["owner.region"], r["count(DISTINCT reachable.account_id)"]) for r in n]

            if compare(
                f"Q4 Case {case} — account {account}, depth {depth}",
                p, n
            ):
                passed += 1

    print(f"\nQ4 cases passed: {passed}/{total}")
    return passed == 24


# ============================================================
# 9. Q5
# ============================================================

def compare_q5(pg, neo):
    print("\n" + "=" * 72)
    print("Q5 — RAPID ONWARD PAYMENTS")
    print("=" * 72)

    passed = 0

    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)

        p = run_pg(pg, SQL_Q5, (account, start, end))
        n = run_neo(
            neo, CYPHER_Q5,
            {"account": account, "start_epoch": start, "end_epoch": end}
        )

        p = [(tuple(r[0]), int(r[1])) for r in p]
        n = [
            (tuple(r["[t1.transfer_id, t2.transfer_id, t3.transfer_id]"]),
             int(r["d.account_id"]))
            for r in n
        ]

        if compare(f"Q5 Case {case} — account {account}", p, n):
            passed += 1

        print("  Matching chains:", len(p))
        for ids, final_receiver in p:
            print(f"    transfer_ids={ids} | final_receiver={final_receiver}")

    print(f"\nQ5 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 10. Q6 — CIRCULAR PAYMENTS
# ============================================================

def compare_q6(pg, neo):
    print("\n" + "=" * 72)
    print("Q6 — CIRCULAR PAYMENTS")
    print("=" * 72)

    passed = 0

    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)

        # SQL uses the review-hour start and end.
        p = run_pg(
            pg,
            SQL_Q6,
            (account, start, end, end),
        )

        n = run_neo(
            neo,
            CYPHER_Q6,
            {
                "account": account,
                "start_epoch": start,
                "end_epoch": end,
            },
        )

        p = [
            (tuple(r[0]), int(r[1]))
            for r in p
        ]
        n = [
            (
                tuple(r["transfer_ids"]),
                int(r["transfer_count"]),
            )
            for r in n
        ]

        if compare(f"Q6 Case {case} — account {account}", p, n):
            passed += 1

        print("  Circular sequences returned:", len(p))
        for ids, length in p:
            print(f"    transfer_ids={ids} | transfer_count={length}")

    print(f"\nQ6 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# Q7 configuration and tested search helpers
Q7_PAIRS = (
    ("A", 998, 24755),
    ("B", 147228, 186823),
    ("C", 206978, 6573),
    ("D", 237998, 21755),
    ("E", 144228, 183823),
    ("F", 203978, 3573),
)
Q7_BOUNDS = (4, 6)

CYPHER_TEMPLATE = """
MATCH p = ANY SHORTEST
    (s:Account {account_id: $start})
    ((a:Account)-[:TRANSFER]->(b:Account)
        WHERE a.role = 'person'
          AND b.role = 'person'
    ){1,BOUND}
    (d:Account {account_id: $destination})
RETURN
    length(p) AS depth,
    [n IN nodes(p) | n.account_id] AS account_path,
    [r IN relationships(p) | r.transfer_id] AS transfer_ids
"""


def normalize_path(depth, account_path, transfer_ids):
    if depth is None:
        return None

    return {
        "depth": int(depth),
        "account_path": [int(x) for x in account_path],
        "transfer_ids": [int(x) for x in transfer_ids],
    }


def get_postgres_path(pg_conn, start, destination, bound):
    """
    Find a shortest directed person-to-person transfer path
    using iterative breadth-first search (BFS).

    BFS explores paths by increasing number of transfers.
    A visited set prevents repeatedly exploring the same account.
    The search stops when the destination is discovered or
    the specified transfer bound is reached.
    """

    # Confirm the starting account exists and has the right role.
    with pg_conn.cursor() as cur:
        cur.execute(
            """
            SELECT account_id
            FROM accounts
            WHERE account_id = %s
              AND role = 'person'
            """,
            (start,),
        )
        if cur.fetchone() is None:
            return None

    # Parent records allow us to reconstruct one shortest path
    # without storing every possible path.
    parent = {start: None}
    parent_transfer = {}

    visited = {start}
    frontier = [start]

    for depth in range(1, bound + 1):
        if not frontier:
            return None

        # Fetch outgoing transfers for the current BFS level.
        # The sender index helps PostgreSQL locate these records.
        with pg_conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    t.sender_id,
                    t.receiver_id,
                    t.transfer_id
                FROM transfers t
                JOIN accounts sender
                    ON sender.account_id = t.sender_id
                   AND sender.role = 'person'
                JOIN accounts receiver
                    ON receiver.account_id = t.receiver_id
                   AND receiver.role = 'person'
                WHERE t.sender_id = ANY(%s)
              
                WHERE t.sender_id = ANY(%s)
                """,
                (frontier,),
            )
            edges = cur.fetchall()
edges.sort(key=lambda edge: (int(edge[0]), int(edge[1]), int(edge[2])))
        next_frontier = []

        for sender_id, receiver_id, transfer_id in edges:
            sender_id = int(sender_id)
            receiver_id = int(receiver_id)
            transfer_id = int(transfer_id)

            # Do not revisit an account already reached by a
            # shorter or equally short BFS route.
            if receiver_id in visited:
                continue

            visited.add(receiver_id)
            parent[receiver_id] = sender_id
            parent_transfer[receiver_id] = transfer_id
            next_frontier.append(receiver_id)

            # The first discovery is a shortest path because
            # BFS processes one transfer level at a time.
            if receiver_id == destination:
                account_path = [destination]
                transfer_ids = []
                current = destination

                while current != start:
                    transfer_ids.append(parent_transfer[current])
                    current = parent[current]
                    account_path.append(current)

                account_path.reverse()
                transfer_ids.reverse()

                return {
                    "depth": len(transfer_ids),
                    "account_path": account_path,
                    "transfer_ids": transfer_ids,
                }

        frontier = next_frontier

    # No route was found within the requested bound.
    return None


def validate_path_against_postgres(
    pg_conn, path, start, destination, bound
):
    """
    Validate a returned path using PostgreSQL source records.

    Checks:
    - expected start and destination
    - path length within the requested bound
    - account count equals transfer count + 1
    - all accounts exist and have role 'person'
    - no repeated accounts
    - every transfer event exists
    - each transfer follows the direction in the path
    """
    errors = []

    if path is None:
        return False, ["There is no supporting path to validate."]

    depth = path["depth"]
    accounts = path["account_path"]
    transfer_ids = path["transfer_ids"]

    if depth < 1 or depth > bound:
        errors.append(
            f"Path length {depth} is outside the allowed range 1..{bound}."
        )

    if len(accounts) != depth + 1:
        errors.append("Account count must equal path length + 1.")

    if len(transfer_ids) != depth:
        errors.append("Transfer ID count must equal path length.")

    if not accounts or accounts[0] != start:
        errors.append(f"Path does not start at account {start}.")

    if not accounts or accounts[-1] != destination:
        errors.append(f"Path does not end at account {destination}.")

    if len(accounts) != len(set(accounts)):
        errors.append("Path repeats an account.")

    with pg_conn.cursor() as cur:
        # Verify all accounts and their roles.
        if accounts:
            cur.execute(
                """
                SELECT account_id, role
                FROM accounts
                WHERE account_id = ANY(%s)
                """,
                (accounts,),
            )
            roles = {
                int(account_id): role
                for account_id, role in cur.fetchall()
            }

            for account_id in accounts:
                if account_id not in roles:
                    errors.append(
                        f"Account {account_id} does not exist in PostgreSQL."
                    )
                elif roles[account_id] != "person":
                    errors.append(
                        f"Account {account_id} has role "
                        f"{roles[account_id]!r}, not 'person'."
                    )

        # Verify transfer existence and directed sender/receiver pairs.
        if len(accounts) == len(transfer_ids) + 1:
            for index, transfer_id in enumerate(transfer_ids):
                expected_sender = accounts[index]
                expected_receiver = accounts[index + 1]

                cur.execute(
                    """
                    SELECT sender_id, receiver_id
                    FROM transfers
                    WHERE transfer_id = %s
                    """,
                    (transfer_id,),
                )
                event = cur.fetchone()

                if event is None:
                    errors.append(
                        f"Transfer event {transfer_id} does not exist."
                    )
                elif (
                    int(event[0]) != expected_sender
                    or int(event[1]) != expected_receiver
                ):
                    errors.append(
                        f"Transfer {transfer_id} direction mismatch: "
                        f"expected {expected_sender}->{expected_receiver}; "
                        f"found {event[0]}->{event[1]}."
                    )

    return not errors, errors


def print_path(label, path):
    print(f"  {label}:")

    if path is None:
        print("    No route found within this bound.")
        return

    print(f"    Shortest length: {path['depth']}")
    print(f"    Account path:    {path['account_path']}")
    print(f"    Transfer IDs:    {path['transfer_ids']}")



def get_neo4j_path(neo, start, destination, bound):
    query = CYPHER_TEMPLATE.replace("BOUND", str(bound))
    record = neo.run(
        query,
        start=start,
        destination=destination,
    ).single()

    if record is None:
        return None

    return normalize_path(
        record["depth"],
        record["account_path"],
        record["transfer_ids"],
    )




# ============================================================
# 11. Q7 — SHORTEST DIRECTED TRANSFER CONNECTIONS
# ============================================================

def compare_q7(pg, neo):
    print("\n" + "=" * 72)
    print("Q7 — SHORTEST DIRECTED TRANSFER CONNECTIONS")
    print("=" * 72)

    length_passed = 0
    validation_passed = 0
    validation_applicable = 0
    validation_failed = 0

    for case_id, start, destination in Q7_PAIRS:
        for bound in Q7_BOUNDS:
            print("\n" + "-" * 72)
            print(
                f"Q7 Case {case_id}: {start} -> {destination}; "
                f"maximum length = {bound}"
            )

            print("Searching PostgreSQL with BFS...")
            pg_path = get_postgres_path(
                pg, start, destination, bound
            )
            print_path("PostgreSQL", pg_path)

            print("Searching Neo4j...")
            neo_path = get_neo4j_path(
                neo, start, destination, bound
            )
            print_path("Neo4j", neo_path)

            # Compare shortest length or no-route outcome only.
            if pg_path is None and neo_path is None:
                length_ok = True
                print("Shortest-length comparison: PASS (neither found a route)")
            elif pg_path is None or neo_path is None:
                length_ok = False
                print("Shortest-length comparison: FAIL (route outcomes differ)")
            elif pg_path["depth"] == neo_path["depth"]:
                length_ok = True
                print(
                    "Shortest-length comparison: PASS "
                    f"(both lengths = {pg_path['depth']})"
                )
                if pg_path["transfer_ids"] != neo_path["transfer_ids"]:
                    print(
                        "Note: transfer IDs differ; equally short valid "
                        "paths can differ between databases."
                    )
            else:
                length_ok = False
                print(
                    "Shortest-length comparison: FAIL "
                    f"(PostgreSQL={pg_path['depth']}, "
                    f"Neo4j={neo_path['depth']})"
                )

            if length_ok:
                length_passed += 1

            # Validate each available path independently against PostgreSQL.
            print("Supporting-path validation:")

            for label, path in (
                ("PostgreSQL", pg_path),
                ("Neo4j", neo_path),
            ):
                if path is None:
                    print(f"  {label}: NOT APPLICABLE (no route returned)")
                    continue

                validation_applicable += 1
                valid, errors = validate_path_against_postgres(
                    pg, path, start, destination, bound
                )

                if valid:
                    validation_passed += 1
                    print(f"  {label}: PASS")
                else:
                    validation_failed += 1
                    print(f"  {label}: FAIL")
                    for error in errors:
                        print(f"    - {error}")

    print("\n" + "=" * 72)
    print("Q7 SUMMARY")
    print("=" * 72)
    print(f"Shortest-length comparisons: {length_passed}/12 PASS")
    print(
        "Supporting paths validated: "
        f"{validation_passed}/{validation_applicable} PASS"
    )
    print(f"Supporting paths failed: {validation_failed}")

    # Q7 passes only when every length comparison matches and every
    # available supporting path passes independent validation.
    all_lengths_pass = length_passed == 12
    all_paths_pass = validation_failed == 0

    return all_lengths_pass and all_paths_pass


# ============================================================
# 12. MAIN PROGRAM

# ============================================================

def main():
    print("=" * 72)
    print("SECTION 6.1 — POSTGRESQL / NEO4J VERIFICATION")
    print("=" * 72)

    pg_password = getpass("PostgreSQL password for postgres: ")
    neo_password = getpass("Neo4j password for neo4j: ")

    pg = None
    driver = None

    try:
        print("\nConnecting to PostgreSQL...")
        pg = psycopg.connect(
            host=PG_HOST,
            port=PG_PORT,
            dbname=PG_DATABASE,
            user=PG_USER,
            password=pg_password,
            connect_timeout=10,
        )
        print("PostgreSQL connection: OK")

        print("\nConnecting to Neo4j...")
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USER, neo_password),
        )
        driver.verify_connectivity()
        print("Neo4j connection: OK")

        with driver.session(database=NEO4J_DATABASE) as neo:
            results = {
                "Q1": compare_q1(pg, neo),
                "Q2": compare_q2(pg, neo),
                "Q3": compare_q3(pg, neo),
                "Q4": compare_q4(pg, neo),
                "Q5": compare_q5(pg, neo),
                "Q6": compare_q6(pg, neo),
                "Q7": compare_q7(pg, neo),
            }

        print("\n" + "=" * 72)
        print("FINAL SUMMARY — SECTION 6.1")
        print("=" * 72)

        for question, ok in results.items():
            print(f"{question}: {'PASS' if ok else 'FAIL'}")

        total_passed = sum(results.values())
        print(f"\nQuestion groups passed: {total_passed}/7")
        print(
            "\nOverall:",
            "ALL QUESTION GROUPS PASSED"
            if all(results.values())
            else "ONE OR MORE QUESTION GROUPS FAILED",
        )

        print("\nComparison counts when all cases run:")
        print("  Q1: 6")
        print("  Q2: 1")
        print("  Q3: 6")
        print("  Q4: 24")
        print("  Q5: 6")
        print("  Q6: 6")
        print("  Q7: 12")
        print("  Total: 61")

    except Exception as exc:
        print("\nERROR:", exc)
        raise

    finally:
        if pg is not None:
            pg.close()
        if driver is not None:
            driver.close()
        print("\nDatabase connections closed.")


if __name__ == "__main__":
    main()
