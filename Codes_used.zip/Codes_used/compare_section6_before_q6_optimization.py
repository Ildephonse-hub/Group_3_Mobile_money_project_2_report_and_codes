
"""
Section 6.1 — PostgreSQL vs Neo4j verification
Q1: Outgoing transfers during the review hour.
Q2: Daily transfer activity in September 2026.
Q3: Shared devices with overlapping usage intervals.
Q4: Ownership/device network reach.
Q5: Rapid onward payments.
Q6: Circular payments.

PostgreSQL: localhost:5433 / mobile_money_investigations
Neo4j: bolt://localhost:7687 / neo4j
"""

from datetime import date, datetime, time
from getpass import getpass
from zoneinfo import ZoneInfo

import psycopg
from neo4j import GraphDatabase


# ============================================================
# 1. CONFIGURATION
# ============================================================

PG_HOST = "localhost"
PG_PORT = 5433
PG_DATABASE = "mobile_money_investigations"
PG_USER = "postgres"

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_DATABASE = "neo4j"

TZ = ZoneInfo("Africa/Kigali")

CASES = (
    ("A", 998, 6),
    ("B", 147228, 13),
    ("C", 206978, 8),
    ("D", 237998, 6),
    ("E", 144228, 13),
    ("F", 203978, 8),
)

Q4_DEPTHS = (4, 6, 8, 10)


# ============================================================
# 2. POSTGRESQL QUERIES
# ============================================================

SQL_Q1 = """
SELECT
    COUNT(t.transfer_id),
    COALESCE(SUM(t.amount_rwf), 0)
FROM accounts a
LEFT JOIN transfers t
    ON t.sender_id = a.account_id
   AND t.occurred_at >= %s
   AND t.occurred_at < %s
WHERE a.account_id = %s
"""


SQL_Q2 = """
WITH days AS (
    SELECT generate_series(
        DATE '2026-09-01',
        DATE '2026-09-30',
        INTERVAL '1 day'
    )::date AS local_day
),
daily AS (
    SELECT
        (to_timestamp(occurred_at)
            AT TIME ZONE 'Africa/Kigali')::date AS local_day,
        COUNT(*) AS transfer_count,
        SUM(amount_rwf) AS total_rwf
    FROM transfers
    WHERE occurred_at >= %s
      AND occurred_at < %s
    GROUP BY 1
)
SELECT
    d.local_day::text,
    COALESCE(x.transfer_count, 0),
    COALESCE(x.total_rwf, 0)
FROM days d
LEFT JOIN daily x USING (local_day)
ORDER BY d.local_day
"""


SQL_Q3 = """
SELECT DISTINCT
    other.account_id,
    d.device_id,
    d.access_type,
    GREATEST(review.first_day, other.first_day),
    LEAST(review.last_day, other.last_day)
FROM account_devices review
JOIN account_devices other
    ON other.device_id = review.device_id
   AND other.account_id <> review.account_id
   AND review.first_day <= other.last_day
   AND other.first_day <= review.last_day
JOIN devices d ON d.device_id = review.device_id
WHERE review.account_id = %s
ORDER BY 1, 2, 3, 4, 5
"""


SQL_Q4 = """
WITH RECURSIVE edges(src, dst) AS (
    SELECT 'C:' || customer_id::text,
           'A:' || account_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'C:' || customer_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'D:' || device_id::text
    FROM account_devices

    UNION

    SELECT 'D:' || device_id::text,
           'A:' || account_id::text
    FROM account_devices
),
walk(node, depth) AS (
    SELECT 'A:' || %s::text, 0

    UNION

    SELECT e.dst, w.depth + 1
    FROM walk w
    JOIN edges e ON e.src = w.node
    WHERE w.depth < %s
),
reachable AS (
    SELECT DISTINCT
        split_part(node, ':', 2)::integer AS account_id
    FROM walk
    WHERE node LIKE 'A:%%'
      AND depth BETWEEN 1 AND %s
)
SELECT
    c.region,
    COUNT(DISTINCT a.account_id)
FROM reachable r
JOIN accounts a ON a.account_id = r.account_id
JOIN customers c ON c.customer_id = a.customer_id
WHERE a.account_id <> %s
GROUP BY c.region
ORDER BY c.region
"""


SQL_Q5 = """
SELECT
    ARRAY[t1.transfer_id, t2.transfer_id, t3.transfer_id],
    t3.receiver_id
FROM transfers t1
JOIN transfers t2 ON t2.sender_id = t1.receiver_id
JOIN transfers t3 ON t3.sender_id = t2.receiver_id
WHERE t1.sender_id = %s
  AND t1.occurred_at >= %s
  AND t1.occurred_at < %s

  AND t2.occurred_at > t1.occurred_at
  AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at
  AND t3.occurred_at <= t2.occurred_at + 600

  AND 100::bigint * t2.amount_rwf >= 90::bigint * t1.amount_rwf
  AND 100::bigint * t2.amount_rwf <= 105::bigint * t1.amount_rwf
  AND 100::bigint * t3.amount_rwf >= 90::bigint * t2.amount_rwf
  AND 100::bigint * t3.amount_rwf <= 105::bigint * t2.amount_rwf

  AND t1.sender_id <> t1.receiver_id
  AND t1.sender_id <> t2.receiver_id
  AND t1.sender_id <> t3.receiver_id
  AND t1.receiver_id <> t2.receiver_id
  AND t1.receiver_id <> t3.receiver_id
  AND t2.receiver_id <> t3.receiver_id
ORDER BY 1, 2
"""


# Q6: Build transfer sequences recursively.
# Each sequence starts at the review account during the review hour.
# All transfers must be within the hour and span <= 1800 seconds.
# The recursion stops when the starting account is reached again.
SQL_Q6 = """
WITH RECURSIVE paths AS (
    SELECT
        t.sender_id AS start_account,
        t.receiver_id AS current_account,
        ARRAY[t.transfer_id]::bigint[] AS transfer_ids,
        ARRAY[t.sender_id, t.receiver_id]::integer[] AS account_path,
        t.occurred_at AS first_time,
        t.occurred_at AS last_time,
        t.amount_rwf AS last_amount,
        1 AS transfer_count
    FROM transfers t
    WHERE t.sender_id = %s
      AND t.occurred_at >= %s
      AND t.occurred_at < %s

    UNION ALL

    SELECT
        p.start_account,
        t.receiver_id,
        p.transfer_ids || t.transfer_id,
        p.account_path || t.receiver_id,
        p.first_time,
        t.occurred_at,
        t.amount_rwf,
        p.transfer_count + 1
    FROM paths p
    JOIN transfers t
      ON t.sender_id = p.current_account
    WHERE p.current_account <> p.start_account
      AND p.transfer_count < 8

      AND t.occurred_at > p.last_time
      AND t.occurred_at < %s
      AND t.occurred_at - p.first_time <= 1800

      AND 100::bigint * t.amount_rwf
          >= 90::bigint * p.last_amount
      AND 100::bigint * t.amount_rwf
          <= 105::bigint * p.last_amount
)
SELECT
    transfer_ids,
    transfer_count
FROM paths
WHERE current_account = start_account
  AND transfer_count BETWEEN 3 AND 8
  AND last_time - first_time <= 1800
ORDER BY transfer_ids
"""


# ============================================================
# 3. NEO4J QUERIES
# ============================================================

CYPHER_Q1 = """
MATCH (a:Account {account_id: $account})
OPTIONAL MATCH (a)-[t:TRANSFER]->()
WHERE t.occurred_at >= $start_epoch
  AND t.occurred_at < $end_epoch
RETURN count(t), coalesce(sum(t.amount_rwf), 0)
"""


CYPHER_Q2 = """
MATCH ()-[t:TRANSFER]->()
WHERE t.occurred_at >= $start_epoch
  AND t.occurred_at < $end_epoch

WITH
    date(datetime({
        epochSeconds: t.occurred_at,
        timezone: "Africa/Kigali"
    })) AS local_day,
    count(t) AS transfer_count,
    sum(t.amount_rwf) AS total_rwf

RETURN
    toString(local_day) AS local_day,
    transfer_count,
    total_rwf
ORDER BY local_day
"""


CYPHER_Q3 = """
MATCH
    (review:Account {account_id: $account})
        -[r:USED_DEVICE]->(d:Device)
        <-[s:USED_DEVICE]-(other:Account)
WHERE other.account_id <> review.account_id
  AND r.first_day <= s.last_day
  AND s.first_day <= r.last_day
RETURN DISTINCT
    other.account_id AS other_account_id,
    d.device_id AS device_id,
    d.access_type AS access_type,
    CASE WHEN r.first_day > s.first_day
         THEN r.first_day ELSE s.first_day END AS overlap_start,
    CASE WHEN r.last_day < s.last_day
         THEN r.last_day ELSE s.last_day END AS overlap_end
ORDER BY other_account_id, device_id, access_type, overlap_start, overlap_end
"""

def cypher_q4(depth):
    return f"""
    MATCH
        (start:Account {{account_id: $account}})
        -[:OWNS|USED_DEVICE*1..{depth}]-
        (reachable:Account)
    WHERE reachable.account_id <> start.account_id
    WITH DISTINCT reachable
    MATCH (owner:Customer)-[:OWNS]->(reachable)
    RETURN owner.region, count(DISTINCT reachable.account_id)
    ORDER BY owner.region
    """


CYPHER_Q5 = """
MATCH
    (a:Account {account_id: $account})
        -[t1:TRANSFER]->(b:Account)
        -[t2:TRANSFER]->(c:Account)
        -[t3:TRANSFER]->(d:Account)
WHERE t1.occurred_at >= $start_epoch
  AND t1.occurred_at < $end_epoch

  AND t2.occurred_at > t1.occurred_at
  AND t2.occurred_at <= t1.occurred_at + 600
  AND t3.occurred_at > t2.occurred_at
  AND t3.occurred_at <= t2.occurred_at + 600

  AND 100 * toInteger(t2.amount_rwf) >= 90 * toInteger(t1.amount_rwf)
  AND 100 * toInteger(t2.amount_rwf) <= 105 * toInteger(t1.amount_rwf)
  AND 100 * toInteger(t3.amount_rwf) >= 90 * toInteger(t2.amount_rwf)
  AND 100 * toInteger(t3.amount_rwf) <= 105 * toInteger(t2.amount_rwf)

  AND a.account_id <> b.account_id
  AND a.account_id <> c.account_id
  AND a.account_id <> d.account_id
  AND b.account_id <> c.account_id
  AND b.account_id <> d.account_id
  AND c.account_id <> d.account_id
RETURN
    [t1.transfer_id, t2.transfer_id, t3.transfer_id],
    d.account_id
ORDER BY 1, 2
"""


# Circular path: start and end at the review account.
# The first transfer must start during the review hour.
# All transfers are inside the hour, increasing in time,
# and the path must return for the first time at its final step.
CYPHER_Q6 = """
MATCH p =
    (a:Account {account_id: $account})
    -[:TRANSFER*3..8]->
    (a)
WITH
    a,
    relationships(p) AS rs,
    nodes(p) AS ns
WHERE
    rs[0].occurred_at >= $start_epoch
    AND rs[0].occurred_at < $end_epoch

    AND all(r IN rs
        WHERE r.occurred_at >= $start_epoch
          AND r.occurred_at < $end_epoch)

    AND all(i IN range(1, size(rs) - 1)
        WHERE rs[i].occurred_at > rs[i - 1].occurred_at)

    AND rs[size(rs) - 1].occurred_at - rs[0].occurred_at <= 1800

    AND all(i IN range(1, size(rs) - 1)
        WHERE 100 * toInteger(rs[i].amount_rwf)
                  >= 90 * toInteger(rs[i - 1].amount_rwf)
          AND 100 * toInteger(rs[i].amount_rwf)
                  <= 105 * toInteger(rs[i - 1].amount_rwf))

    AND none(n IN ns[1..-1]
        WHERE n.account_id = $account)

RETURN
    [r IN rs | r.transfer_id] AS transfer_ids,
    size(rs) AS transfer_count
ORDER BY transfer_ids
"""


# ============================================================
# 4. COMMON HELPERS
# ============================================================

def september_epoch_bounds():
    start = datetime.combine(
        date(2026, 9, 1), time(0, 0), tzinfo=TZ
    )
    end = datetime.combine(
        date(2026, 10, 1), time(0, 0), tzinfo=TZ
    )
    return int(start.timestamp()), int(end.timestamp())


def q1_epoch_bounds(day_number):
    d = date(2026, 9, day_number)
    start = datetime.combine(d, time(9, 45), tzinfo=TZ)
    end = datetime.combine(d, time(10, 45), tzinfo=TZ)
    return int(start.timestamp()), int(end.timestamp())


def run_pg(conn, query, params=()):
    with conn.cursor() as cur:
        cur.execute(query, params)
        return cur.fetchall()


def run_neo(session, query, params=None):
    return [
        record.data()
        for record in session.run(query, params or {})
    ]


def normalize(rows):
    result = []
    for row in rows:
        if isinstance(row, dict):
            row = tuple(row.values())
        else:
            row = tuple(row)

        values = []
        for value in row:
            if isinstance(value, (list, tuple)):
                value = tuple(value)
            values.append(value)

        result.append(tuple(values))
    return sorted(result, key=repr)


def compare(title, pg_rows, neo_rows):
    # Each engine's output is converted into a comparable format.
    p = normalize(pg_rows)
    n = normalize(neo_rows)
    passed = p == n

    print("\n" + title)
    print("  PostgreSQL rows:", len(pg_rows))
    print("  Neo4j rows:     ", len(neo_rows))
    print("  RESULT:", "PASS" if passed else "FAIL")

    if not passed:
        print("  PostgreSQL:", p)
        print("  Neo4j:     ", n)

    return passed


# ============================================================
# 5. Q1
# ============================================================

def compare_q1(pg, neo):
    print("\n" + "=" * 72)
    print("Q1 — OUTGOING TRANSFER ACTIVITY")
    print("=" * 72)

    passed = 0
    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)
        p = run_pg(pg, SQL_Q1, (start, end, account))
        n = run_neo(
            neo, CYPHER_Q1,
            {"account": account, "start_epoch": start, "end_epoch": end}
        )
        n = [(r["count(t)"], r["coalesce(sum(t.amount_rwf), 0)"]) for r in n]

        if compare(f"Q1 Case {case} — account {account}", p, n):
            passed += 1

    print(f"\nQ1 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 6. Q2
# ============================================================

def compare_q2(pg, neo):
    print("\n" + "=" * 72)
    print("Q2 — DAILY TRANSFER ACTIVITY")
    print("=" * 72)

    start, end = september_epoch_bounds()
    p = run_pg(pg, SQL_Q2, (start, end))
    n = run_neo(
        neo, CYPHER_Q2,
        {"start_epoch": start, "end_epoch": end}
    )

    daily_by_date = {
        r["local_day"]: (
            int(r["transfer_count"]),
            int(r["total_rwf"] or 0),
        )
        for r in n
    }

    n = [
        (
            f"2026-09-{day:02d}",
            daily_by_date.get(f"2026-09-{day:02d}", (0, 0))[0],
            daily_by_date.get(f"2026-09-{day:02d}", (0, 0))[1],
        )
        for day in range(1, 31)
    ]

    ok = compare("Q2 — all 30 September dates", p, n)

    if ok:
        print("\nSeptember transfer count:", sum(int(r[1]) for r in p))
        print("September total RWF:     ", sum(int(r[2]) for r in p))

    return ok
# ============================================================
# 7. Q3
# ============================================================

def compare_q3(pg, neo):
    print("\n" + "=" * 72)
    print("Q3 — SHARED DEVICES AND OVERLAPPING USAGE")
    print("=" * 72)

    passed = 0
    for case, account, _day in CASES:
        p = run_pg(pg, SQL_Q3, (account,))
        n = run_neo(neo, CYPHER_Q3, {"account": account})

        n = [
            (
                r["other_account_id"],
                r["device_id"],
                r["access_type"],
                r["overlap_start"],
                r["overlap_end"],
            )
            for r in n
        ]

        if compare(f"Q3 Case {case} — account {account}", p, n):
            passed += 1

    print(f"\nQ3 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 8. Q4
# ============================================================

def compare_q4(pg, neo):
    print("\n" + "=" * 72)
    print("Q4 — OWNERSHIP AND DEVICE NETWORK REACH")
    print("=" * 72)

    passed = 0
    total = 0

    for case, account, _day in CASES:
        for depth in Q4_DEPTHS:
            total += 1
            p = run_pg(pg, SQL_Q4, (account, depth, depth, account))
            n = run_neo(neo, cypher_q4(depth), {"account": account})
            n = [(r["owner.region"], r["count(DISTINCT reachable.account_id)"]) for r in n]

            if compare(
                f"Q4 Case {case} — account {account}, depth {depth}",
                p, n
            ):
                passed += 1

    print(f"\nQ4 cases passed: {passed}/{total}")
    return passed == 24


# ============================================================
# 9. Q5
# ============================================================

def compare_q5(pg, neo):
    print("\n" + "=" * 72)
    print("Q5 — RAPID ONWARD PAYMENTS")
    print("=" * 72)

    passed = 0

    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)

        p = run_pg(pg, SQL_Q5, (account, start, end))
        n = run_neo(
            neo, CYPHER_Q5,
            {"account": account, "start_epoch": start, "end_epoch": end}
        )

        p = [(tuple(r[0]), int(r[1])) for r in p]
        n = [
            (tuple(r["[t1.transfer_id, t2.transfer_id, t3.transfer_id]"]),
             int(r["d.account_id"]))
            for r in n
        ]

        if compare(f"Q5 Case {case} — account {account}", p, n):
            passed += 1

        print("  Matching chains:", len(p))
        for ids, final_receiver in p:
            print(f"    transfer_ids={ids} | final_receiver={final_receiver}")

    print(f"\nQ5 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 10. Q6 — CIRCULAR PAYMENTS
# ============================================================

def compare_q6(pg, neo):
    print("\n" + "=" * 72)
    print("Q6 — CIRCULAR PAYMENTS")
    print("=" * 72)

    passed = 0

    for case, account, day in CASES:
        start, end = q1_epoch_bounds(day)

        # SQL uses the review-hour start and end.
        p = run_pg(
            pg,
            SQL_Q6,
            (account, start, end, end),
        )

        n = run_neo(
            neo,
            CYPHER_Q6,
            {
                "account": account,
                "start_epoch": start,
                "end_epoch": end,
            },
        )

        p = [
            (tuple(r[0]), int(r[1]))
            for r in p
        ]
        n = [
            (
                tuple(r["transfer_ids"]),
                int(r["transfer_count"]),
            )
            for r in n
        ]

        if compare(f"Q6 Case {case} — account {account}", p, n):
            passed += 1

        print("  Circular sequences returned:", len(p))
        for ids, length in p:
            print(f"    transfer_ids={ids} | transfer_count={length}")

    print(f"\nQ6 cases passed: {passed}/6")
    return passed == 6


# ============================================================
# 11. MAIN PROGRAM
# ============================================================

def main():
    print("=" * 72)
    print("SECTION 6.1 — POSTGRESQL / NEO4J VERIFICATION")
    print("=" * 72)

    pg_password = getpass("PostgreSQL password for postgres: ")
    neo_password = getpass("Neo4j password for neo4j: ")

    pg = None
    driver = None

    try:
        print("\nConnecting to PostgreSQL...")
        pg = psycopg.connect(
            host=PG_HOST,
            port=PG_PORT,
            dbname=PG_DATABASE,
            user=PG_USER,
            password=pg_password,
            connect_timeout=10,
        )
        print("PostgreSQL connection: OK")

        print("\nConnecting to Neo4j...")
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USER, neo_password),
        )
        driver.verify_connectivity()
        print("Neo4j connection: OK")

        with driver.session(database=NEO4J_DATABASE) as neo:
            results = {
                "Q1": compare_q1(pg, neo),
                "Q2": compare_q2(pg, neo),
                "Q3": compare_q3(pg, neo),
                "Q4": compare_q4(pg, neo),
                "Q5": compare_q5(pg, neo),
                "Q6": compare_q6(pg, neo),
            }

        print("\n" + "=" * 72)
        print("FINAL SUMMARY — SECTION 6.1")
        print("=" * 72)

        for question, ok in results.items():
            print(f"{question}: {'PASS' if ok else 'FAIL'}")

        total_passed = sum(results.values())
        print(f"\nQuestion groups passed: {total_passed}/6")
        print(
            "\nOverall:",
            "ALL QUESTION GROUPS PASSED"
            if all(results.values())
            else "ONE OR MORE QUESTION GROUPS FAILED",
        )

        print("\nComparison counts when all cases run:")
        print("  Q1: 6")
        print("  Q2: 1")
        print("  Q3: 6")
        print("  Q4: 24")
        print("  Q5: 6")
        print("  Q6: 6")
        print("  Total: 49")

    except Exception as exc:
        print("\nERROR:", exc)
        raise

    finally:
        if pg is not None:
            pg.close()
        if driver is not None:
            driver.close()
        print("\nDatabase connections closed.")


if __name__ == "__main__":
    main()
