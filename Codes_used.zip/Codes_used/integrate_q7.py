﻿from pathlib import Path
import ast
import shutil
from datetime import datetime

main_path = Path("compare_section6.py")
test_path = Path("test_q7_only.py")

if not main_path.exists() or not test_path.exists():
    raise SystemExit(
        "STOP: compare_section6.py or test_q7_only.py was not found."
    )

main_source = main_path.read_text(encoding="utf-8")
test_source = test_path.read_text(encoding="utf-8")

if 'def compare_q7(pg, neo):' in main_source:
    raise SystemExit("STOP: Q7 appears to be integrated already.")

main_tree = ast.parse(main_source)
test_tree = ast.parse(test_source)

def source_of(node, source):
    lines = source.splitlines(keepends=True)
    return "".join(lines[node.lineno - 1:node.end_lineno])

test_nodes = {
    node.name: node
    for node in test_tree.body
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
}

required_functions = [
    "normalize_path",
    "get_postgres_path",
    "validate_path_against_postgres",
    "print_path",
]

missing = [name for name in required_functions if name not in test_nodes]
if missing:
    raise SystemExit(f"STOP: Missing tested functions: {missing}")

cypher_node = next(
    (
        node for node in test_tree.body
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name)
            and target.id == "CYPHER_TEMPLATE"
            for target in node.targets
        )
    ),
    None,
)
if cypher_node is None:
    raise SystemExit("STOP: CYPHER_TEMPLATE was not found.")

# Use the tested Cypher template, but reuse the main program's
# already-open Neo4j session instead of opening another session.
cypher_source = source_of(cypher_node, test_source)

neo_helper = '''
def get_neo4j_path(neo, start, destination, bound):
    query = CYPHER_TEMPLATE.replace("BOUND", str(bound))
    record = neo.run(
        query,
        start=start,
        destination=destination,
    ).single()

    if record is None:
        return None

    return normalize_path(
        record["depth"],
        record["account_path"],
        record["transfer_ids"],
    )
'''

helper_parts = [
    "# Q7 configuration and tested search helpers",
    'Q7_PAIRS = (',
    '    ("A", 998, 24755),',
    '    ("B", 147228, 186823),',
    '    ("C", 206978, 6573),',
    '    ("D", 237998, 21755),',
    '    ("E", 144228, 183823),',
    '    ("F", 203978, 3573),',
    ')',
    'Q7_BOUNDS = (4, 6)',
    '',
    cypher_source,
    '',
]

for name in required_functions:
    helper_parts.append(source_of(test_nodes[name], test_source))
    helper_parts.append("")

helper_parts.append(neo_helper)
helper_parts.append("")

q7_comparison = r'''
# ============================================================
# 11. Q7 — SHORTEST DIRECTED TRANSFER CONNECTIONS
# ============================================================

def compare_q7(pg, neo):
    print("\n" + "=" * 72)
    print("Q7 — SHORTEST DIRECTED TRANSFER CONNECTIONS")
    print("=" * 72)

    length_passed = 0
    validation_passed = 0
    validation_applicable = 0
    validation_failed = 0

    for case_id, start, destination in Q7_PAIRS:
        for bound in Q7_BOUNDS:
            print("\n" + "-" * 72)
            print(
                f"Q7 Case {case_id}: {start} -> {destination}; "
                f"maximum length = {bound}"
            )

            print("Searching PostgreSQL with BFS...")
            pg_path = get_postgres_path(
                pg, start, destination, bound
            )
            print_path("PostgreSQL", pg_path)

            print("Searching Neo4j...")
            neo_path = get_neo4j_path(
                neo, start, destination, bound
            )
            print_path("Neo4j", neo_path)

            # Compare shortest length or no-route outcome only.
            if pg_path is None and neo_path is None:
                length_ok = True
                print("Shortest-length comparison: PASS (neither found a route)")
            elif pg_path is None or neo_path is None:
                length_ok = False
                print("Shortest-length comparison: FAIL (route outcomes differ)")
            elif pg_path["depth"] == neo_path["depth"]:
                length_ok = True
                print(
                    "Shortest-length comparison: PASS "
                    f"(both lengths = {pg_path['depth']})"
                )
                if pg_path["transfer_ids"] != neo_path["transfer_ids"]:
                    print(
                        "Note: transfer IDs differ; equally short valid "
                        "paths can differ between databases."
                    )
            else:
                length_ok = False
                print(
                    "Shortest-length comparison: FAIL "
                    f"(PostgreSQL={pg_path['depth']}, "
                    f"Neo4j={neo_path['depth']})"
                )

            if length_ok:
                length_passed += 1

            # Validate each available path independently against PostgreSQL.
            print("Supporting-path validation:")

            for label, path in (
                ("PostgreSQL", pg_path),
                ("Neo4j", neo_path),
            ):
                if path is None:
                    print(f"  {label}: NOT APPLICABLE (no route returned)")
                    continue

                validation_applicable += 1
                valid, errors = validate_path_against_postgres(
                    pg, path, start, destination, bound
                )

                if valid:
                    validation_passed += 1
                    print(f"  {label}: PASS")
                else:
                    validation_failed += 1
                    print(f"  {label}: FAIL")
                    for error in errors:
                        print(f"    - {error}")

    print("\n" + "=" * 72)
    print("Q7 SUMMARY")
    print("=" * 72)
    print(f"Shortest-length comparisons: {length_passed}/12 PASS")
    print(
        "Supporting paths validated: "
        f"{validation_passed}/{validation_applicable} PASS"
    )
    print(f"Supporting paths failed: {validation_failed}")

    # Q7 passes only when every length comparison matches and every
    # available supporting path passes independent validation.
    all_lengths_pass = length_passed == 12
    all_paths_pass = validation_failed == 0

    return all_lengths_pass and all_paths_pass
'''

# Ensure expected insertion and summary text are present before modifying.
main_marker = "# 11. MAIN PROGRAM"
if main_marker not in main_source:
    raise SystemExit("STOP: Main-program insertion marker not found.")

expected_results = '''                "Q6": compare_q6(pg, neo),
            }'''
if expected_results not in main_source:
    raise SystemExit("STOP: Expected results dictionary was not found.")

expected_summary = '''        print(f"\\nQuestion groups passed: {total_passed}/6")'''
if expected_summary not in main_source:
    raise SystemExit("STOP: Expected question-group summary was not found.")

expected_total = '        print("  Total: 49")'
if expected_total not in main_source:
    raise SystemExit("STOP: Expected total-count line was not found.")

# Build the new file entirely in memory before writing.
updated = main_source.replace(
    main_marker,
    "\n".join(helper_parts) + "\n\n" + q7_comparison
    + "\n\n# ============================================================\n"
    + "# 12. MAIN PROGRAM\n",
    1,
)

updated = updated.replace(
    expected_results,
    '''                "Q6": compare_q6(pg, neo),
                "Q7": compare_q7(pg, neo),
            }''',
    1,
)

updated = updated.replace(
    expected_summary,
    '''        print(f"\\nQuestion groups passed: {total_passed}/7")''',
    1,
)

updated = updated.replace(
    '        print("  Q6: 6")\n        print("  Total: 49")',
    '        print("  Q6: 6")\n'
    '        print("  Q7: 12")\n'
    '        print("  Total: 61")',
    1,
)

# Parse before writing so a syntax error cannot overwrite the working file.
try:
    ast.parse(updated)
except SyntaxError as exc:
    raise SystemExit(f"STOP: Generated code has a syntax error: {exc}")

backup = Path(
    "compare_section6_before_q7_"
    + datetime.now().strftime("%Y%m%d_%H%M%S")
    + ".py"
)
shutil.copy2(main_path, backup)
main_path.write_text(updated, encoding="utf-8")

print("Q7 integration completed.")
print(f"Backup created: {backup}")
print("Q1-Q6 code retained; Q7 added.")
print("Expected total comparisons: 61")
