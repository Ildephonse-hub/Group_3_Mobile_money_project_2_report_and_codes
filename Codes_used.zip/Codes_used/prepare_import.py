
import csv
import time
from pathlib import Path

# Project folders
BASE_DIR = Path(__file__).resolve().parent
SOURCE_DIR = BASE_DIR / "output"
IMPORT_DIR = BASE_DIR / "neo4j_import"

# Create a separate folder for Neo4j import copies.
# The original source files will not be changed.
IMPORT_DIR.mkdir(parents=True, exist_ok=True)

start_time = time.perf_counter()
counts = {}


def stream_csv(source_name, output_name, output_header, transform):
    """Read one CSV row at a time and write its Neo4j import copy."""
    source_path = SOURCE_DIR / source_name
    output_path = IMPORT_DIR / output_name
    count = 0

    with source_path.open("r", newline="", encoding="utf-8-sig") as source:
        reader = csv.DictReader(source)

        with output_path.open(
            "w", newline="", encoding="utf-8"
        ) as output:
            writer = csv.writer(output, lineterminator="\n")
            writer.writerow(output_header)

            for row in reader:
                writer.writerow(transform(row))
                count += 1

    counts[output_name] = count
    print(f"{output_name}: {count:,} data rows written")


# 1. Customer nodes
stream_csv(
    "customers.csv",
    "customers.csv",
    ["customer_id:ID(Customer)", "region:string"],
    lambda row: [
        row["customer_id"],
        row["region"],
    ],
)

# 2. Account nodes
# customer_id is retained as an ignored CSV column.
# The ownership relationship is created separately in owns.csv.
stream_csv(
    "accounts.csv",
    "accounts.csv",
    ["account_id:ID(Account)", ":IGNORE", "role:string"],
    lambda row: [
        row["account_id"],
        row["customer_id"],
        row["role"],
    ],
)

# 3. Device nodes
stream_csv(
    "devices.csv",
    "devices.csv",
    ["device_id:ID(Device)", "access_type:string"],
    lambda row: [
        row["device_id"],
        row["access_type"],
    ],
)

# 4. Ownership relationships: Customer -> Account
# The required column order is customer_id, account_id.
stream_csv(
    "accounts.csv",
    "owns.csv",
    [":START_ID(Customer)", ":END_ID(Account)"],
    lambda row: [
        row["customer_id"],
        row["account_id"],
    ],
)

# 5. Device-use relationships: Account -> Device
# Preserve all three observation properties.
stream_csv(
    "account_devices.csv",
    "used_device.csv",
    [
        ":START_ID(Account)",
        ":END_ID(Device)",
        "first_day:int",
        "last_day:int",
        "observations:int",
    ],
    lambda row: [
        row["account_id"],
        row["device_id"],
        row["first_day"],
        row["last_day"],
        row["observations"],
    ],
)

# 6. Transfer relationships: Account -> Account
# Each source row produces its own relationship.
stream_csv(
    "transfers.csv",
    "transfers.csv",
    [
        "transfer_id:long",
        ":START_ID(Account)",
        ":END_ID(Account)",
        "occurred_at:long",
        "amount_rwf:int",
    ],
    lambda row: [
        row["transfer_id"],
        row["sender_id"],
        row["receiver_id"],
        row["occurred_at"],
        row["amount_rwf"],
    ],
)

elapsed = time.perf_counter() - start_time

print("\nPreparation completed.")
print(f"Output folder: {IMPORT_DIR}")
print(f"Elapsed seconds: {elapsed:.3f}")
print("\nOutput file sizes (decimal MB):")

for filename in [
    "customers.csv",
    "accounts.csv",
    "devices.csv",
    "owns.csv",
    "used_device.csv",
    "transfers.csv",
]:
    path = IMPORT_DIR / filename
    size_mb = path.stat().st_size / 1_000_000
    print(f"{filename}: {size_mb:.3f} MB")

# Expected counts from the capture audit
expected = {
    "customers.csv": 228_000,
    "accounts.csv": 248_000,
    "devices.csv": 228_600,
    "owns.csv": 248_000,
    "used_device.csv": 285_600,
    "transfers.csv": 20_003_300,
}

print("\nExpected-count checks:")
all_match = True

for filename, expected_count in expected.items():
    actual_count = counts[filename]
    matches = actual_count == expected_count
    all_match = all_match and matches
    print(
        f"{filename}: actual={actual_count:,}, "
        f"expected={expected_count:,}, match={matches}"
    )

print(f"\nALL COUNTS MATCH: {all_match}")

if not all_match:
    raise SystemExit(
        "ERROR: At least one count differs. Do not run the Neo4j import yet."
    )
