"""
Section 6.1 verification: PostgreSQL versus Neo4j
Mobile Money Investigations — Q1 through Q6

Run:
  python compare_section6.py

The script prompts for passwords and does not store them in the file.
"""
from __future__ import annotations

import getpass
import os
import sys
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import psycopg
from neo4j import GraphDatabase


# ---------------------------------------------------------------------------
# CONNECTION SETTINGS
# ---------------------------------------------------------------------------
PG_HOST = "localhost"
PG_PORT = 5433
PG_DB = "mobile_money_investigations"
PG_USER = "postgres"

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_DATABASE = "neo4j"

LOCAL_TZ = ZoneInfo("Africa/Kigali")

CASES = (
    ("A", 998, 6),
    ("B", 147228, 13),
    ("C", 206978, 8),
    ("D", 237998, 6),
    ("E", 144228, 13),
    ("F", 203978, 8),
)
Q4_DEPTHS = (4, 6, 8, 10)


# ---------------------------------------------------------------------------
# SQL QUERIES
# ---------------------------------------------------------------------------

# Q1: outgoing transfers from the reviewed account in [09:45, 10:45) CAT
# on that case's review day in September 2026.
SQL_Q1 = """
SELECT
    COUNT(*)::BIGINT AS transfer_count,
    COALESCE(SUM(t.amount_rwf), 0)::BIGINT AS total_rwf
FROM transfers AS t
WHERE t.sender_id = %(account)s
  AND t.occurred_at >= %(start_epoch)s
  AND t.occurred_at <  %(end_epoch)s
"""

# Q2: each local calendar date in September 2026, including dates with no
# transfers. Unix epoch seconds are converted to CAT before grouping.
SQL_Q2 = """
WITH dates AS (
    SELECT generate_series(
        DATE '2026-09-01',
        DATE '2026-09-30',
        INTERVAL '1 day'
    )::date AS local_day
),
daily AS (
    SELECT
        (to_timestamp(t.occurred_at) AT TIME ZONE 'Africa/Kigali')::date
            AS local_day,
        COUNT(*)::BIGINT AS transfer_count,
        COALESCE(SUM(t.amount_rwf), 0)::BIGINT AS total_rwf
    FROM transfers AS t
    WHERE t.occurred_at >= %(month_start_epoch)s
      AND t.occurred_at <  %(month_end_epoch)s
    GROUP BY 1
)
SELECT
    dates.local_day,
    COALESCE(daily.transfer_count, 0)::BIGINT AS transfer_count,
    COALESCE(daily.total_rwf, 0)::BIGINT AS total_rwf
FROM dates
LEFT JOIN daily USING (local_day)
ORDER BY dates.local_day
"""

# Q3: shared devices whose inclusive use-day intervals overlap.
SQL_Q3 = """
SELECT DISTINCT
    other.account_id AS other_account_id,
    d.device_id AS device_id,
    d.access_type AS access_type,
    GREATEST(review_use.first_day, other_use.first_day) AS overlap_start,
    LEAST(review_use.last_day, other_use.last_day) AS overlap_end
FROM account_devices AS review_use
JOIN devices AS d
  ON d.device_id = review_use.device_id
JOIN account_devices AS other_use
  ON other_use.device_id = review_use.device_id
JOIN accounts AS other
  ON other.account_id = other_use.account_id
WHERE review_use.account_id = %(account)s
  AND other.account_id <> review_use.account_id
  AND review_use.first_day <= other_use.last_day
  AND other_use.first_day <= review_use.last_day
ORDER BY other_account_id, device_id, access_type, overlap_start, overlap_end
"""

# Q4: distinct accounts reachable through OWNS / USED_DEVICE only, undirected,
# at no more than the specified number of relationships. Each account is
# grouped by the region of its owner/customer. The review account is excluded.
SQL_Q4 = """
WITH RECURSIVE walk(account_id, depth, path) AS (
    SELECT %(account)s::INTEGER, 0, ARRAY[%(account)s::INTEGER]
    UNION ALL
    SELECT next_account.account_id, walk.depth + 1,
           walk.path || next_account.account_id
    FROM walk
    JOIN account_devices AS ad
      ON ad.account_id = walk.account_id
    JOIN account_devices AS other_ad
      ON other_ad.device_id = ad.device_id
     AND other_ad.account_id <> walk.account_id
    JOIN accounts AS next_account
      ON next_account.account_id = other_ad.account_id
    WHERE walk.depth < %(max_depth)s
      AND NOT next_account.account_id = ANY(walk.path)
),
reachable AS (
    SELECT DISTINCT account_id
    FROM walk
    WHERE depth > 0
)
SELECT
    c.region AS owner_region,
    COUNT(DISTINCT r.account_id)::BIGINT AS account_count
FROM reachable AS r
JOIN accounts AS a ON a.account_id = r.account_id
JOIN customers AS c ON c.customer_id = a.customer_id
GROUP BY c.region
ORDER BY c.region
"""

# Q5: exactly three directed transfers / four account nodes. First transfer
# must start within the review hour. Each next transfer must occur strictly
# later and within 600 seconds of the previous transfer. Amount of each later
# transfer must be 90%-105% of the previous transfer, inclusive. Later legs
# may extend beyond the review hour. No role restriction.
SQL_Q5 = """
WITH RECURSIVE chains AS (
    SELECT
        t1.sender_id AS start_account,
        t1.receiver_id AS current_account,
        ARRAY[t1.transfer_id]::BIGINT[] AS transfer_ids,
        ARRAY[t1.sender_id, t1.receiver_id]::INTEGER[] AS account_path,
        t1.occurred_at AS last_time,
        t1.amount_rwf AS last_amount,
        1 AS transfer_count
    FROM transfers AS t1
    WHERE t1.sender_id = %(account)s
      AND t1.occurred_at >= %(start_epoch)s
      AND t1.occurred_at <  %(end_epoch)s

    UNION ALL

    SELECT
        chains.start_account,
        t.sender_id * 0 + t.receiver_id AS current_account,
        chains.transfer_ids || t.transfer_id,
        chains.account_path || t.receiver_id,
        t.occurred_at,
        t.amount_rwf,
        chains.transfer_count + 1
    FROM chains
    JOIN transfers AS t
      ON t.sender_id = chains.current_account
    WHERE chains.transfer_count < 3
      AND t.occurred_at > chains.last_time
      AND t.occurred_at <= chains.last_time + 600
      AND t.amount_rwf >= chains.last_amount * 0.90
      AND t.amount_rwf <= chains.last_amount * 1.05
      AND NOT t.receiver_id = ANY(chains.account_path)
)
SELECT
    transfer_ids,
    current_account AS final_receiver
FROM chains
WHERE transfer_count = 3
ORDER BY transfer_ids, final_receiver
"""

# Q6: circular payments, 3–8 transfers, starts and ends at review account.
# All transfers fall in the review hour, strictly increasing, total span <=
# 1800 seconds, and each later amount is 90%-105% of previous. Stop at first
# return to the start; other accounts may repeat.
SQL_Q6 = """
WITH RECURSIVE cycles AS (
    SELECT
        t1.sender_id AS start_account,
        t1.receiver_id AS current_account,
        ARRAY[t1.transfer_id]::BIGINT[] AS transfer_ids,
        ARRAY[t1.sender_id, t1.receiver_id]::INTEGER[] AS account_path,
        t1.occurred_at AS first_time,
        t1.occurred_at AS last_time,
        t1.amount_rwf AS last_amount,
        1 AS transfer_count
    FROM transfers AS t1
    WHERE t1.sender_id = %(account)s
      AND t1.occurred_at >= %(start_epoch)s
      AND t1.occurred_at <  %(end_epoch)s

    UNION ALL

    SELECT
        cycles.start_account,
        t.receiver_id AS current_account,
        cycles.transfer_ids || t.transfer_id,
        cycles.account_path || t.receiver_id,
        cycles.first_time,
        t.occurred_at AS last_time,
        t.amount_rwf AS last_amount,
        cycles.transfer_count + 1
    FROM cycles
    JOIN transfers AS t
      ON t.sender_id = cycles.current_account
    WHERE cycles.transfer_count < 8
      AND cycles.current_account <> cycles.start_account
      AND t.occurred_at > cycles.last_time
      AND t.occurred_at < %(end_epoch)s
      AND t.occurred_at - cycles.first_time <= 1800
      AND t.amount_rwf >= cycles.last_amount * 0.90
      AND t.amount_rwf <= cycles.last_amount * 1.05
)
SELECT
    transfer_ids,
    transfer_count
FROM cycles
WHERE current_account = start_account
  AND transfer_count BETWEEN 3 AND 8
ORDER BY transfer_count, transfer_ids
"""


# ---------------------------------------------------------------------------
# CYPHER QUERIES
# ---------------------------------------------------------------------------
CYPHER_Q1 = """
MATCH (a:Account {account_id: $account})
OPTIONAL MATCH (a)-[t:TRANSFER]->()
WHERE t.occurred_at >= $start_epoch AND t.occurred_at < $end_epoch
RETURN count(t) AS transfer_count,
       coalesce(sum(t.amount_rwf), 0) AS total_rwf
"""

CYPHER_Q2 = """
UNWIND range(0, 29) AS day_offset
WITH date('2026-09-01') + duration({days: day_offset}) AS local_day
OPTIONAL MATCH (s:Account)-[t:TRANSFER]->(r:Account)
WHERE datetime({epochSeconds: t.occurred_at}).timezone = 'UTC'
WITH local_day, t
WHERE t IS NULL OR
      date(datetime({epochSeconds: t.occurred_at}).epochSeconds) IS NULL
RETURN local_day, count(t) AS transfer_count,
       coalesce(sum(t.amount_rwf), 0) AS total_rwf
ORDER BY local_day
"""

# A separate reliable query groups event timestamps by Kigali local date.
# Neo4j datetime epoch conversion is UTC; adding the fixed CAT offset gives
# the local date (Rwanda is UTC+02:00, without daylight saving time).
CYPHER_Q2_DAILY = """
UNWIND range(0, 29) AS day_offset
WITH date('2026-09-01') + duration({days: day_offset}) AS local_day
OPTIONAL MATCH (s:Account)-[t:TRANSFER]->(r:Account)
WHERE t IS NULL OR
      date(datetime({epochSeconds: t.occurred_at}) + duration({hours: 2}))
        = local_day
RETURN local_day AS local_day,
       count(t) AS transfer_count,
       coalesce(sum(t.amount_rwf), 0) AS total_rwf
ORDER BY local_day
"""

CYPHER_Q3 = """
MATCH
    (review:Account {account_id: $account})
        -[r:USED_DEVICE]->(d:Device)
        <-[s:USED_DEVICE]-(other:Account)
WHERE other.account_id <> review.account_id
  AND r.first_day <= s.last_day
  AND s.first_day <= r.last_day
RETURN DISTINCT
    other.account_id AS other_account_id,
    d.device_id AS device_id,
    d.access_type AS access_type,
    CASE WHEN r.first_day > s.first_day
         THEN r.first_day ELSE s.first_day END AS overlap_start,
    CASE WHEN r.last_day < s.last_day
         THEN r.last_day ELSE s.last_day END AS overlap_end
ORDER BY other_account_id, device_id, access_type, overlap_start, overlap_end
"""

CYPHER_Q4 = """
MATCH (start:Account {account_id: $account})
MATCH p = (start)-[:OWNS|USED_DEVICE*1..10]-(reachable:Account)
WHERE length(p) <= $max_depth
  AND reachable.account_id <> start.account_id
WITH DISTINCT reachable
MATCH (owner:Customer)-[:OWNS]->(reachable)
RETURN owner.region AS owner_region,
       count(DISTINCT reachable.account_id) AS account_count
ORDER BY owner_region
"""

CYPHER_Q5 = """
MATCH (a:Account {account_id: $account})
      -[t1:TRANSFER]->(b:Account)
WHERE t1.occurred_at >= $start_epoch AND t1.occurred_at < $end_epoch
MATCH (b)-[t2:TRANSFER]->(c:Account)
WHERE t2.occurred_at > t1.occurred_at
  AND t2.occurred_at <= t1.occurred_at + 600
  AND t2.amount_rwf >= t1.amount_rwf * 0.90
  AND t2.amount_rwf <= t1.amount_rwf * 1.05
MATCH (c)-[t3:TRANSFER]->(d:Account)
WHERE t3.occurred_at > t2.occurred_at
  AND t3.occurred_at <= t2.occurred_at + 600
  AND t3.amount_rwf >= t2.amount_rwf * 0.90
  AND t3.amount_rwf <= t2.amount_rwf * 1.05
RETURN [t1.transfer_id, t2.transfer_id, t3.transfer_id] AS transfer_ids,
       d.account_id AS final_receiver
ORDER BY transfer_ids, final_receiver
"""

CYPHER_Q6 = """
MATCH (start:Account {account_id: $account})
MATCH p = (start)-[:TRANSFER*3..8]->(end:Account)
WHERE end.account_id = start.account_id
WITH p, relationships(p) AS rs, nodes(p) AS ns
WHERE all(i IN range(0, size(rs)-1)
          WHERE rs[i].occurred_at >= $start_epoch
            AND rs[i].occurred_at < $end_epoch)
  AND all(i IN range(1, size(rs)-1)
          WHERE rs[i].occurred_at > rs[i-1].occurred_at
            AND rs[i].occurred_at - rs[i-1].occurred_at >= 0
            AND rs[i].amount_rwf >= rs[i-1].amount_rwf * 0.90
            AND rs[i].amount_rwf <= rs[i-1].amount_rwf * 1.05)
  AND rs[size(rs)-1].occurred_at - rs[0].occurred_at <= 1800
  AND none(i IN range(1, size(ns)-1)
           WHERE ns[i].account_id = start.account_id)
RETURN [r IN rs | r.transfer_id] AS transfer_ids,
       size(rs) AS transfer_count
ORDER BY transfer_count, transfer_ids
"""


# ---------------------------------------------------------------------------
# TIME / DATABASE HELPERS
# ---------------------------------------------------------------------------
def epoch_for_local_datetime(day: int, hour: int, minute: int) -> int:
    local_dt = datetime(2026, 9, day, hour, minute, tzinfo=LOCAL_TZ)
    return int(local_dt.timestamp())


def case_hour(day: int) -> tuple[int, int]:
    return (
        epoch_for_local_datetime(day, 9, 45),
        epoch_for_local_datetime(day, 10, 45),
    )


def month_bounds() -> tuple[int, int]:
    start = datetime(2026, 9, 1, 0, 0, tzinfo=LOCAL_TZ)
    end = datetime(2026, 10, 1, 0, 0, tzinfo=LOCAL_TZ)
    return int(start.timestamp()), int(end.timestamp())


def pg_connect(password: str):
    return psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DB,
        user=PG_USER,
        password=password,
        connect_timeout=15,
    )


def run_pg(conn, query: str, params: dict | None = None):
    with conn.cursor() as cur:
        cur.execute(query, params or {})
        return cur.fetchall()


def run_neo(session, query: str, params: dict | None = None):
    return [dict(record) for record in session.run(query, params or {})]


def normalize_rows(rows):
    def norm(value):
        if isinstance(value, list):
            return tuple(norm(v) for v in value)
        if isinstance(value, tuple):
            return tuple(norm(v) for v in value)
        if hasattr(value, "iso_format"):
            return value.iso_format()
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return value
    return sorted(tuple(norm(v) for v in row) for row in rows)


def print_case_result(label: str, pg_rows, neo_rows) -> bool:
    pg_n = normalize_rows(pg_rows)
    neo_n = normalize_rows(neo_rows)
    passed = pg_n == neo_n
    print(f"\n{label}")
    print(f"  PostgreSQL rows: {len(pg_n)}")
    print(f"  Neo4j rows:      {len(neo_n)}")
    print(f"  RESULT: {'PASS' if passed else 'FAIL'}")
    if not passed:
        print("  PostgreSQL result:")
        for row in pg_n[:20]:
            print("   ", row)
        print("  Neo4j result:")
        for row in neo_n[:20]:
            print("   ", row)
    return passed


# ---------------------------------------------------------------------------
# Q1–Q6 COMPARISONS
# ---------------------------------------------------------------------------
def compare_q1(pg, neo) -> int:
    passed = 0
    for label, account, day in CASES:
        start_epoch, end_epoch = case_hour(day)
        params = {"account": account, "start_epoch": start_epoch, "end_epoch": end_epoch}
        p = run_pg(pg, SQL_Q1, params)
        n_records = run_neo(neo, CYPHER_Q1, params)
        n = [(r["transfer_count"], r["total_rwf"]) for r in n_records]
        passed += print_case_result(f"Q1 Case {label} — account {account}", p, n)
    print(f"\nQ1 cases passed: {passed}/6")
    return passed


def compare_q2(pg, neo) -> int:
    month_start, month_end = month_bounds()
    p = run_pg(pg, SQL_Q2, {
        "month_start_epoch": month_start,
        "month_end_epoch": month_end,
    })
    # Neo4j date math: create 30 CAT dates and count matching transfers.
    # Epoch seconds are shifted +2 hours to represent Africa/Kigali local time.
    query = """
    UNWIND range(0, 29) AS offset
    WITH date('2026-09-01') + duration({days: offset}) AS local_day
    OPTIONAL MATCH (s:Account)-[t:TRANSFER]->(r:Account)
    WHERE t IS NULL OR
          (t.occurred_at >= $month_start_epoch
           AND t.occurred_at < $month_end_epoch
           AND date(datetime({epochSeconds: t.occurred_at}) + duration({hours: 2})
                    ) = local_day)
    RETURN local_day AS local_day,
           count(t) AS transfer_count,
           coalesce(sum(t.amount_rwf), 0) AS total_rwf
    ORDER BY local_day
    """
    n_records = run_neo(neo, query, {
        "month_start_epoch": month_start,
        "month_end_epoch": month_end,
    })
    n = [(r["local_day"].to_native(), r["transfer_count"], r["total_rwf"])
         for r in n_records]
    p = [(row[0], row[1], row[2]) for row in p]
    # psycopg date and Neo4j native date both compare as date objects.
    ok = print_case_result("Q2 — all 30 September dates", p, n)
    if p:
        print(f"\nSeptember transfer count: {sum(row[1] for row in p)}")
        print(f"September total RWF:      {sum(row[2] for row in p)}")
    return int(ok)


def compare_q3(pg, neo) -> int:
    passed = 0
    for label, account, _day in CASES:
        params = {"account": account}
        p = run_pg(pg, SQL_Q3, params)
        n_records = run_neo(neo, CYPHER_Q3, params)
        n = [
            (
                r["other_account_id"],
                r["device_id"],
                r["access_type"],
                r["overlap_start"],
                r["overlap_end"],
            )
            for r in n_records
        ]
        passed += print_case_result(f"Q3 Case {label} — account {account}", p, n)
    print(f"\nQ3 cases passed: {passed}/6")
    return passed


def compare_q4(pg, neo) -> int:
    passed = 0
    for label, account, _day in CASES:
        for depth in Q4_DEPTHS:
            params = {"account": account, "max_depth": depth}
            p = run_pg(pg, SQL_Q4, params)
            n_records = run_neo(neo, CYPHER_Q4, params)
            n = [(r["owner_region"], r["account_count"]) for r in n_records]
            passed += print_case_result(
                f"Q4 Case {label} — account {account}, depth {depth}", p, n
            )
    print(f"\nQ4 comparisons passed: {passed}/24")
    return passed


def compare_q5(pg, neo) -> int:
    passed = 0
    for label, account, day in CASES:
        start_epoch, end_epoch = case_hour(day)
        params = {"account": account, "start_epoch": start_epoch, "end_epoch": end_epoch}
        p = run_pg(pg, SQL_Q5, params)
        n_records = run_neo(neo, CYPHER_Q5, params)
        n = [(r["transfer_ids"], r["final_receiver"]) for r in n_records]
        passed += print_case_result(f"Q5 Case {label} — account {account}", p, n)
    print(f"\nQ5 cases passed: {passed}/6")
    return passed


def compare_q6(pg, neo) -> int:
    passed = 0
    for label, account, day in CASES:
        start_epoch, end_epoch = case_hour(day)
        params = {"account": account, "start_epoch": start_epoch, "end_epoch": end_epoch}
        p = run_pg(pg, SQL_Q6, params)
        n_records = run_neo(neo, CYPHER_Q6, params)
        n = [(r["transfer_ids"], r["transfer_count"]) for r in n_records]
        passed += print_case_result(f"Q6 Case {label} — account {account}", p, n)
    print(f"\nQ6 cases passed: {passed}/6")
    return passed


def main() -> int:
    print("=" * 72)
    print("SECTION 6.1 — POSTGRESQL / NEO4J VERIFICATION")
    print("=" * 72)

    pg_password = getpass.getpass(f"PostgreSQL password for {PG_USER}: ")
    neo_password = getpass.getpass(f"Neo4j password for {NEO4J_USER}: ")

    pg = None
    driver = None
    passed_by_question = {}
    try:
        print("\nConnecting to PostgreSQL...")
        pg = pg_connect(pg_password)
        print("PostgreSQL connection: OK")

        print("\nConnecting to Neo4j...")
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USER, neo_password),
        )
        driver.verify_connectivity()
        print("Neo4j connection: OK")

        with driver.session(database=NEO4J_DATABASE) as neo:
            print("\n" + "=" * 72)
            print("Q1 — OUTGOING TRANSFER ACTIVITY")
            print("=" * 72)
            passed_by_question["Q1"] = (compare_q1(pg, neo), 6)

            print("\n" + "=" * 72)
            print("Q2 — DAILY TRANSFER ACTIVITY")
            print("=" * 72)
            passed_by_question["Q2"] = (compare_q2(pg, neo), 1)

            print("\n" + "=" * 72)
            print("Q3 — SHARED DEVICES AND OVERLAPPING USAGE")
            print("=" * 72)
            passed_by_question["Q3"] = (compare_q3(pg, neo), 6)

            print("\n" + "=" * 72)
            print("Q4 — ACCOUNT REACHABILITY BY OWNER REGION")
            print("=" * 72)
            passed_by_question["Q4"] = (compare_q4(pg, neo), 24)

            print("\n" + "=" * 72)
            print("Q5 — THREE-TRANSFER CHAINS")
            print("=" * 72)
            passed_by_question["Q5"] = (compare_q5(pg, neo), 6)

            print("\n" + "=" * 72)
            print("Q6 — CIRCULAR PAYMENTS")
            print("=" * 72)
            passed_by_question["Q6"] = (compare_q6(pg, neo), 6)

        print("\n" + "=" * 72)
        print("SECTION 6.1 SUMMARY")
        print("=" * 72)
        for question, (passed, total) in passed_by_question.items():
            print(f"{question}: {passed}/{total}")
        passed_total = sum(v[0] for v in passed_by_question.values())
        expected_total = sum(v[1] for v in passed_by_question.values())
        print(f"TOTAL: {passed_total}/{expected_total}")
        return 0 if passed_total == expected_total else 1

    except Exception as exc:
        print(f"\nERROR: {exc}")
        raise
    finally:
        if pg is not None:
            pg.close()
        if driver is not None:
            driver.close()
        print("\nDatabase connections closed.")


if __name__ == "__main__":
    sys.exit(main())
