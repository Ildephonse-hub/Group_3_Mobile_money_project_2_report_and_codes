
import psycopg
from getpass import getpass

# Connect to the PostgreSQL database used by the assignment.
password = getpass("PostgreSQL password: ")

conn = psycopg.connect(
    host="::1",
    port=5433,
    dbname="mobile_money_investigations",
    user="postgres",
    password=password,
)

try:
    # Inspect the query plan without executing the query.
    # These are the accounts in Q7 case B.
    frontier = [147228]

    with conn.cursor() as cur:
        cur.execute(
            """
            EXPLAIN
            SELECT
                t.sender_id,
                t.receiver_id,
                t.transfer_id
            FROM transfers t
            JOIN accounts sender
                ON sender.account_id = t.sender_id
               AND sender.role = 'person'
            JOIN accounts receiver
                ON receiver.account_id = t.receiver_id
               AND receiver.role = 'person'
            WHERE t.sender_id = ANY(%s)
            ORDER BY
                t.sender_id,
                t.receiver_id,
                t.transfer_id
            """,
            (frontier,),
        )

        for row in cur.fetchall():
            print(row[0])

finally:
    conn.close()
    print("PostgreSQL connection closed.")
