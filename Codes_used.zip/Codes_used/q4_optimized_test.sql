EXPLAIN (COSTS, VERBOSE, SETTINGS)
WITH RECURSIVE
edges(src_type, src_id, dst_type, dst_id) AS (
    SELECT 1, customer_id, 2, account_id
    FROM accounts

    UNION

    SELECT 2, account_id, 1, customer_id
    FROM accounts

    UNION

    SELECT 2, account_id, 3, device_id
    FROM account_devices

    UNION

    SELECT 3, device_id, 2, account_id
    FROM account_devices
),
walk(node_type, node_id, depth) AS (
    SELECT 2, 147228, 0

    UNION

    SELECT e.dst_type, e.dst_id, w.depth + 1
    FROM walk w
    JOIN edges e
      ON e.src_type = w.node_type
     AND e.src_id = w.node_id
    WHERE w.depth < 4
),
reachable AS (
    SELECT DISTINCT node_id AS account_id
    FROM walk
    WHERE node_type = 2
      AND depth BETWEEN 1 AND 4
)
SELECT
    c.region,
    COUNT(DISTINCT a.account_id)
FROM reachable r
JOIN accounts a ON a.account_id = r.account_id
JOIN customers c ON c.customer_id = a.customer_id
WHERE a.account_id <> 147228
GROUP BY c.region
ORDER BY c.region;
