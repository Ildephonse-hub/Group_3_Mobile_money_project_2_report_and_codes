"""
Section 7: Concurrent load testing for Mobile Money Investigations.

Tests PostgreSQL and Neo4j using:
- Q4: ownership/device network reach, maximum depth 10.
- Q7: shortest directed transfer path, maximum bound 6.
- A, B, C test cases.
- 1, 4, 8, and 16 concurrent clients.
- Three repetitions per configuration.

This is a new script. It does not modify the Section 6 scripts.
"""

import csv
import json
import math
import multiprocessing as mp
import statistics
import time
import traceback
from collections import defaultdict
from datetime import datetime
from getpass import getpass
from pathlib import Path

import psycopg
from neo4j import GraphDatabase, Query
import matplotlib.pyplot as plt



# ============================================================
# 1. CONFIGURATION
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_DIR / "section7_results"

PG_HOST = "localhost"
PG_PORT = 5433
PG_DATABASE = "mobile_money_investigations"
PG_USER = "postgres"

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_DATABASE = "neo4j"

CLIENT_COUNTS = (1, 4, 8, 16)
REPETITIONS = 3
RUN_SECONDS = 15
QUERY_TIMEOUT_SECONDS = 60

# The assignment requires A-B-C cycles.
Q4_CASES = (
    ("A", 998),
    ("B", 147228),
    ("C", 206978),
)

Q7_CASES = (
    ("A", 998, 24755),
    ("B", 147228, 186823),
    ("C", 206978, 6573),
)

Q4_DEPTH = 10
Q7_BOUND = 6

WORKLOADS = ("Q4", "Q7")
ENGINES = ("PostgreSQL", "Neo4j")


# ============================================================
# 2. SELECTED Q4 SQL
# ============================================================

SQL_Q4 = """
WITH RECURSIVE edges(src, dst) AS (
    SELECT 'C:' || customer_id::text,
           'A:' || account_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'C:' || customer_id::text
    FROM accounts

    UNION

    SELECT 'A:' || account_id::text,
           'D:' || device_id::text
    FROM account_devices

    UNION

    SELECT 'D:' || device_id::text,
           'A:' || account_id::text
    FROM account_devices
),
walk(node, depth) AS (
    SELECT 'A:' || %s::text, 0

    UNION

    SELECT e.dst, w.depth + 1
    FROM walk w
    JOIN edges e ON e.src = w.node
    WHERE w.depth < %s
),
reachable AS (
    SELECT DISTINCT
        split_part(node, ':', 2)::integer AS account_id
    FROM walk
    WHERE node LIKE 'A:%%'
      AND depth BETWEEN 1 AND %s
)
SELECT
    c.region,
    COUNT(DISTINCT a.account_id)
FROM reachable r
JOIN accounts a ON a.account_id = r.account_id
JOIN customers c ON c.customer_id = a.customer_id
WHERE a.account_id <> %s
GROUP BY c.region
ORDER BY c.region
"""


def q4_cypher(depth):
    """Return Q4 Cypher with the requested maximum traversal depth."""
    return f"""
    MATCH
        (start:Account {{account_id: $account}})
        -[:OWNS|USED_DEVICE*1..{depth}]-
        (reachable:Account)
    WHERE reachable.account_id <> start.account_id
    WITH DISTINCT reachable
    MATCH (owner:Customer)-[:OWNS]->(reachable)
    RETURN owner.region AS region,
           count(DISTINCT reachable.account_id) AS account_count
    ORDER BY region
    """


# ============================================================
# 3. SELECTED Q7 QUERY
# ============================================================

# PostgreSQL Q7 uses the Section 6.3 optimized approach:
# fetch outgoing edges without SQL ORDER BY, then sort them in Python.
SQL_Q7_EDGES = """
SELECT
    t.sender_id,
    t.receiver_id,
    t.transfer_id
FROM transfers t
JOIN accounts sender
    ON sender.account_id = t.sender_id
   AND sender.role = 'person'
JOIN accounts receiver
    ON receiver.account_id = t.receiver_id
   AND receiver.role = 'person'
WHERE t.sender_id = ANY(%s)
"""


Q7_CYPHER = """
MATCH p = ANY SHORTEST
    (s:Account {account_id: $start})
    ((a:Account)-[:TRANSFER]->(b:Account)
        WHERE a.role = 'person'
          AND b.role = 'person'
    ){1,6}
    (d:Account {account_id: $destination})
RETURN
    length(p) AS depth,
    [n IN nodes(p) | n.account_id] AS accounts,
    [r IN relationships(p) | r.transfer_id] AS transfer_ids
"""
# ============================================================
# 4. DATABASE CONNECTIONS
# ============================================================

def connect_postgres(password):
    """Open one persistent PostgreSQL connection for this client."""
    conn = psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DATABASE,
        user=PG_USER,
        password=password,
        connect_timeout=15,
    )

    # Each SQL statement is limited to 60 seconds.
    with conn.cursor() as cur:
        cur.execute("SET statement_timeout = '60s'")

    conn.commit()
    return conn


def connect_neo4j(password):
    """Open a Neo4j driver for this client process."""
    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, password),
        connection_timeout=15,
        max_connection_pool_size=1,
    )
    driver.verify_connectivity()
    return driver


# ============================================================
# 5. QUERY EXECUTION
# ============================================================

def execute_q4_postgres(conn, account):
    """Execute Q4 at depth 10 and return normalized region counts."""
    params = (account, Q4_DEPTH, Q4_DEPTH, account)

    with conn.cursor() as cur:
        cur.execute(SQL_Q4, params)
        rows = cur.fetchall()

    return sorted(
        [(str(region), int(count)) for region, count in rows],
        key=lambda row: row[0],
    )


def execute_q4_neo4j(driver, account):
    """Execute the equivalent Q4 query in Neo4j."""
    with driver.session(database=NEO4J_DATABASE) as session:
        result = session.run(
            Query(q4_cypher(Q4_DEPTH), timeout=QUERY_TIMEOUT_SECONDS),
            account=account,
        )
        rows = [
            (str(record["region"]), int(record["account_count"]))
            for record in result
        ]

    return sorted(rows, key=lambda row: row[0])


def execute_q7_postgres(conn, start, destination):
    """
    Execute the Section 6.3 optimized PostgreSQL Q7 BFS.

    SQL fetches outgoing edges without ORDER BY.
    Python restores deterministic sender/receiver/transfer ordering.
    """
    start = int(start)
    destination = int(destination)

    if start == destination:
        return {
            "depth": 0,
            "accounts": [start],
            "transfer_ids": [],
        }

    frontier = [start]
    visited = {start}
    parent = {}

    for depth in range(1, Q7_BOUND + 1):
        if not frontier:
            break

        with conn.cursor() as cur:
            cur.execute(SQL_Q7_EDGES, (frontier,))
            edges = cur.fetchall()

        edges.sort(
            key=lambda edge: (
                int(edge[0]),
                int(edge[1]),
                int(edge[2]),
            )
        )

        next_frontier = []

        for sender, receiver, transfer_id in edges:
            sender = int(sender)
            receiver = int(receiver)
            transfer_id = int(transfer_id)

            if receiver in visited:
                continue

            visited.add(receiver)
            parent[receiver] = (sender, transfer_id)

            if receiver == destination:
                accounts = [destination]
                transfer_ids = []
                current = destination

                while current != start:
                    previous, used_transfer = parent[current]
                    transfer_ids.append(used_transfer)
                    accounts.append(previous)
                    current = previous

                accounts.reverse()
                transfer_ids.reverse()

                return {
                    "depth": len(transfer_ids),
                    "accounts": accounts,
                    "transfer_ids": transfer_ids,
                }

            next_frontier.append(receiver)

        frontier = next_frontier

    return None


def execute_q7_neo4j(driver, start, destination):
    """Execute the Section 6.1 shortest-path Cypher query."""
    with driver.session(database=NEO4J_DATABASE) as session:
        record = session.run(
            Query(Q7_CYPHER, timeout=QUERY_TIMEOUT_SECONDS),
            start=int(start),
            destination=int(destination),
        ).single()

    if record is None:
        return None

    return {
        "depth": int(record["depth"]),
        "accounts": [int(value) for value in record["accounts"]],
        "transfer_ids": [int(value) for value in record["transfer_ids"]],
    }


# ============================================================
# 6. RESULT NORMALIZATION
# ============================================================

def normalize_q7(result):
    """Keep the path properties needed for correctness comparisons."""
    if result is None:
        return None

    return {
        "depth": int(result["depth"]),
        "accounts": [int(value) for value in result["accounts"]],
        "transfer_ids": [int(value) for value in result["transfer_ids"]],
    }


def execute_request(engine, workload, connection, case):
    """Run one request for a given engine and workload."""
    if workload == "Q4":
        case_id, account = case

        if engine == "PostgreSQL":
            result = execute_q4_postgres(connection, account)
        else:
            result = execute_q4_neo4j(connection, account)

        return {
            "case_id": case_id,
            "result": result,
        }

    case_id, start, destination = case

    if engine == "PostgreSQL":
        result = execute_q7_postgres(connection, start, destination)
    else:
        result = execute_q7_neo4j(connection, start, destination)

    return {
        "case_id": case_id,
        "result": normalize_q7(result),
    }

    
# ============================================================
# 7. CONCURRENT CLIENT WORKER
# ============================================================

def client_worker(
    engine,
    workload,
    client_id,
    repetition,
    password,
    start_barrier,
    shared_start_time,
    deadline_seconds,
    result_queue,
):
    """
    Run one simulated analyst using one persistent connection.

    Each client warms up A-B-C before synchronization.
    After the barrier releases, it completes whole A-B-C cycles
    until the deadline has passed.
    """

    connection = None
    completed_requests = []
    worker_errors = []

    try:
        # Open one persistent connection for this client.
        if engine == "PostgreSQL":
            connection = connect_postgres(password)
        else:
            connection = connect_neo4j(password)

        # Choose the correct A-B-C test cases.
        cases = Q4_CASES if workload == "Q4" else Q7_CASES

        # Warm up each case once before timing starts.
        for case in cases:
            try:
                execute_request(engine, workload, connection, case)
            except Exception as exc:
                worker_errors.append({
                    "stage": "warmup",
                    "case_id": case[0],
                    "error": repr(exc),
                })

        # Synchronize all client processes.
        
        try:
            start_barrier.wait(timeout=120)
        except Exception as exc:
            result_queue.put({
                "engine": engine,
                "workload": workload,
                "client_id": client_id,
                "repetition": repetition,
                "fatal_error": (
                    "Client could not reach the synchronization barrier: "
                    + repr(exc)
                ),
                "traceback": traceback.format_exc(),
                "requests": completed_requests,
                "worker_errors": worker_errors,
            })
            return


        # The barrier action records the shared start time.
        start_time = shared_start_time.value
        deadline = start_time + deadline_seconds

        request_number = 0
        cycle_number = 0

        while time.perf_counter() < deadline:
            cycle_number += 1

            # Complete the whole A-B-C cycle once it begins.
            for case in cases:
                request_number += 1
                request_start = time.perf_counter()

                try:
                    output = execute_request(
                        engine,
                        workload,
                        connection,
                        case,
                    )
                    elapsed_ms = (
                        time.perf_counter() - request_start
                    ) * 1000

                    completed_requests.append({
                        "engine": engine,
                        "workload": workload,
                        "client_id": client_id,
                        "repetition": repetition,
                        "request_number": request_number,
                        "cycle_number": cycle_number,
                        "case_id": case[0],
                        "latency_ms": elapsed_ms,
                        "status": "completed",
                        "result": output["result"],
                        "error": "",
                    })

                except Exception as exc:
                    elapsed_ms = (
                        time.perf_counter() - request_start
                    ) * 1000

                    error_text = repr(exc)
                    is_timeout = (
                        "timeout" in error_text.lower()
                        or "canceling statement" in error_text.lower()
                    )

                    completed_requests.append({
                        "engine": engine,
                        "workload": workload,
                        "client_id": client_id,
                        "repetition": repetition,
                        "request_number": request_number,
                        "cycle_number": cycle_number,
                        "case_id": case[0],
                        "latency_ms": elapsed_ms,
                        "status": "timeout" if is_timeout else "error",
                        "result": None,
                        "error": error_text,
                    })

        # Send this client's measurements to the parent process.
        result_queue.put({
            "engine": engine,
            "workload": workload,
            "client_id": client_id,
            "repetition": repetition,
            "start_time": start_time,
            "finish_time": time.perf_counter(),
            "requests": completed_requests,
            "worker_errors": worker_errors,
        })

    except Exception as exc:
        result_queue.put({
            "engine": engine,
            "workload": workload,
            "client_id": client_id,
            "repetition": repetition,
            "fatal_error": repr(exc),
            "traceback": traceback.format_exc(),
            "requests": completed_requests,
            "worker_errors": worker_errors,
        })

    finally:
        # Close the client's connection after its work finishes.
        try:
            if connection is not None:
                if engine == "PostgreSQL":
                    connection.close()
                else:
                    connection.close()
        except Exception:
            pass



# ============================================================
# 8. SYNCHRONIZED START-TIME SUPPORT
# ============================================================

class BarrierStartAction:
    """Pickleable barrier action for Windows multiprocessing spawn."""

    def __init__(self, shared_start_time):
        self.shared_start_time = shared_start_time

    def __call__(self):
        # Called once when all clients and the parent reach the barrier.
        self.shared_start_time.value = time.perf_counter()


def create_start_barrier(client_count, shared_start_time, context=None):
    """Create a barrier for clients plus the parent process."""
    context = context or mp.get_context("spawn")
    return context.Barrier(
        client_count + 1,
        action=BarrierStartAction(shared_start_time),
    )



# ============================================================
# 9. RUN ONE CONCURRENT TEST
# ============================================================

def run_one_test(engine, workload, client_count, repetition, password):
    """Run one engine/workload/client-count repetition."""

    print(
        f"\nStarting: engine={engine}, workload={workload}, "
        f"clients={client_count}, repetition={repetition}",
        flush=True,
    )

    context = mp.get_context("spawn")
    shared_start_time = context.Value("d", 0.0)
    result_queue = context.Queue()

    barrier = create_start_barrier(
        client_count,
        shared_start_time,
        context=context,
    )

    cases = Q4_CASES if workload == "Q4" else Q7_CASES

    processes = []

    for client_id in range(1, client_count + 1):
        process = context.Process(
            target=client_worker,
            args=(
                engine,
                workload,
                client_id,
                repetition,
                password,
                barrier,
                shared_start_time,
                RUN_SECONDS,
                result_queue,
            ),
        )
        processes.append(process)
        process.start()

    # The parent joins the barrier as the final participant.
    # This releases the workers only after they have warmed up.
    
    barrier_failed = False

    try:
        barrier.wait(timeout=180)
    except Exception as exc:
        barrier_failed = True
        print(
            f"ERROR: synchronization barrier failed: {exc}",
            flush=True,
        )

    if barrier_failed:
        # Stop clients rather than measuring an invalid run.
        for process in processes:
            if process.is_alive():
                process.terminate()

        for process in processes:
            process.join()

        result_queue.close()

        raise RuntimeError(
            "Benchmark aborted because clients did not synchronize. "
            "No valid timing results were produced for this repetition."
        )


    # Allow each worker to finish any cycle already in progress.
    for process in processes:
        process.join(timeout=RUN_SECONDS + QUERY_TIMEOUT_SECONDS + 180)

    # Stop any process that failed to exit within the safety limit.
    for process in processes:
        if process.is_alive():
            print(
                f"WARNING: terminating unresponsive client "
                f"process {process.pid}",
                flush=True,
            )
            process.terminate()
            process.join()

    worker_results = []

    for _ in processes:
        try:
            worker_results.append(result_queue.get(timeout=10))
        except Exception:
            worker_results.append({
                "engine": engine,
                "workload": workload,
                "repetition": repetition,
                "fatal_error": "No result received from a client process.",
            })

    result_queue.close()

    # Calculate the wall-clock measurement window.
    start_time = shared_start_time.value
    finish_times = [
        result["finish_time"]
        for result in worker_results
        if "finish_time" in result
    ]

    elapsed_seconds = (
        max(finish_times) - start_time
        if finish_times and start_time > 0
        else 0.0
    )

    # Flatten all request logs.
    request_logs = []
    worker_errors = []
    fatal_errors = []

    for result in worker_results:
        request_logs.extend(result.get("requests", []))
        worker_errors.extend(result.get("worker_errors", []))

        if "fatal_error" in result:
            fatal_errors.append({
                "client_id": result.get("client_id"),
                "error": result["fatal_error"],
                "traceback": result.get("traceback", ""),
            })

    successful = [
        row for row in request_logs
        if row.get("status") == "completed"
    ]
    errors = [
        row for row in request_logs
        if row.get("status") == "error"
    ]
    timeouts = [
        row for row in request_logs
        if row.get("status") == "timeout"
    ]

    latencies = sorted(
        row["latency_ms"] for row in successful
    )

    if latencies:
        median_latency_ms = statistics.median(latencies)
        p95_position = math.ceil(0.95 * len(latencies))
        p95_latency_ms = latencies[p95_position - 1]
    else:
        median_latency_ms = None
        p95_latency_ms = None

    throughput = (
        len(successful) / elapsed_seconds
        if elapsed_seconds > 0
        else 0.0
    )

    summary = {
        "engine": engine,
        "workload": workload,
        "client_count": client_count,
        "repetition": repetition,
        "elapsed_seconds": round(elapsed_seconds, 6),
        "completed_requests": len(successful),
        "throughput_requests_per_second": round(throughput, 6),
        "median_latency_ms": (
            round(median_latency_ms, 3)
            if median_latency_ms is not None else None
        ),
        "p95_latency_ms": (
            round(p95_latency_ms, 3)
            if p95_latency_ms is not None else None
        ),
        "errors": len(errors),
        "timeouts": len(timeouts),
        "worker_fatal_errors": len(fatal_errors),
    }

    print("Repetition summary:", summary, flush=True)

    return {
        "summary": summary,
        "requests": request_logs,
        "worker_errors": worker_errors,
        "fatal_errors": fatal_errors,
    }


# ============================================================
# 10. SAVE REQUEST LOGS AND REPETITION SUMMARIES
# ============================================================

def save_csv(path, rows):
    """Save dictionaries to CSV, including an empty-file header."""
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        path.write_text("", encoding="utf-8")
        return

    # Collect columns in first-seen order across all records.
    fieldnames = []
    seen = set()

    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)

    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
            extrasaction="ignore",
        )
        writer.writeheader()

        for row in rows:
            # Store structured query results as JSON text.
            safe_row = {
                key: (
                    json.dumps(value, ensure_ascii=False)
                    if isinstance(value, (dict, list, tuple))
                    else value
                )
                for key, value in row.items()
            }
            writer.writerow(safe_row)


def save_repetition_output(test_result):
    """Save the request log and errors for one repetition."""
    summary = test_result["summary"]

    filename_prefix = (
        f"{summary['engine'].lower()}_"
        f"{summary['workload'].lower()}_"
        f"{summary['client_count']}clients_"
        f"rep{summary['repetition']}"
    )

    save_csv(
        OUTPUT_DIR / f"{filename_prefix}_requests.csv",
        test_result["requests"],
    )

    save_csv(
        OUTPUT_DIR / f"{filename_prefix}_worker_errors.csv",
        test_result["worker_errors"],
    )

    save_csv(
        OUTPUT_DIR / f"{filename_prefix}_fatal_errors.csv",
        test_result["fatal_errors"],
    )

    save_csv(
        OUTPUT_DIR / f"{filename_prefix}_summary.csv",
        [summary],
    )

    print(
        f"Saved repetition output: {filename_prefix}",
        flush=True,
    )



# ============================================================
# 11. CORRECTNESS VALIDATION
# ============================================================

def validate_q4_result(result):
    """
    Basic structural validation for Q4.

    Each result must contain unique region names and non-negative
    account counts. Exact correctness is checked against a
    reference result produced before the timed run.
    """
    if not isinstance(result, list):
        return False

    regions = [region for region, count in result]

    if len(regions) != len(set(regions)):
        return False

    return all(
        isinstance(region, str)
        and isinstance(count, int)
        and count >= 0
        for region, count in result
    )


def validate_q7_result(result, start, destination):
    """
    Validate the structure of a Q7 shortest-path response.

    A missing path is permitted when no route exists within the
    configured bound. The exact shortest distance is checked
    against a preflight reference before timed measurements.
    """
    if result is None:
        return True

    if not isinstance(result, dict):
        return False

    accounts = result.get("accounts")
    transfer_ids = result.get("transfer_ids")
    depth = result.get("depth")

    if not isinstance(accounts, list):
        return False

    if not isinstance(transfer_ids, list):
        return False

    if not isinstance(depth, int):
        return False

    if len(accounts) != len(transfer_ids) + 1:
        return False

    if len(transfer_ids) != depth:
        return False

    if not accounts or accounts[0] != start:
        return False

    if accounts[-1] != destination:
        return False

    if depth < 1 or depth > Q7_BOUND:
        return False

    return True


def compare_q7_shortest_lengths(postgres_result, neo4j_result):
    """
    Compare shortest-path lengths without requiring identical
    account sequences or transfer IDs.
    """
    if postgres_result is None and neo4j_result is None:
        return True

    if postgres_result is None or neo4j_result is None:
        return False

    return (
        postgres_result["depth"] == neo4j_result["depth"]
    )



# ============================================================
# 12. PREFLIGHT CHECK BEFORE TIMED TESTS
# ============================================================

def run_preflight(pg_password, neo4j_password):
    """
    Check PostgreSQL and Neo4j results before load testing.
    These requests are not included in timed measurements.
    """
    print("\nRunning preflight correctness checks...", flush=True)

    pg_conn = None
    neo4j_driver = None
    checks = []

    try:
        pg_conn = connect_postgres(pg_password)
        neo4j_driver = connect_neo4j(neo4j_password)

        # Check Q4 results at depth 10 for A, B, and C.
        for case_id, account in Q4_CASES:
            pg_result = execute_q4_postgres(pg_conn, account)
            neo_result = execute_q4_neo4j(neo4j_driver, account)

            passed = (
                validate_q4_result(pg_result)
                and validate_q4_result(neo_result)
                and pg_result == neo_result
            )

            checks.append({
                "workload": "Q4",
                "case_id": case_id,
                "passed": passed,
                "details": (
                    f"PostgreSQL total={sum(v for _, v in pg_result)}; "
                    f"Neo4j total={sum(v for _, v in neo_result)}"
                ),
            })

        # Check Q7 shortest-path results for A, B, and C.
        for case_id, start, destination in Q7_CASES:
            pg_result = execute_q7_postgres(
                pg_conn, start, destination
            )
            neo_result = execute_q7_neo4j(
                neo4j_driver, start, destination
            )

            pg_valid = validate_q7_result(
                pg_result, start, destination
            )
            neo_valid = validate_q7_result(
                neo_result, start, destination
            )

            
            passed = (
                pg_valid
                and neo_valid
                and compare_q7_shortest_lengths(
                    pg_result, neo_result
                )
                and validate_q7_transfers(pg_conn, pg_result)
                and validate_q7_transfers(pg_conn, neo_result)
            )


            checks.append({
                "workload": "Q7",
                "case_id": case_id,
                "passed": passed,
                "details": (
                    f"PostgreSQL depth="
                    f"{None if pg_result is None else pg_result['depth']}; "
                    f"Neo4j depth="
                    f"{None if neo_result is None else neo_result['depth']}"
                ),
            })

        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        save_csv(OUTPUT_DIR / "preflight_checks.csv", checks)

        print("\nPreflight results:", flush=True)
        for check in checks:
            print(check, flush=True)

        if not all(check["passed"] for check in checks):
            raise RuntimeError(
                "Preflight failed. Do not run the timed benchmark "
                "until the failing cases are investigated."
            )

        print("\nAll preflight checks passed.", flush=True)

    finally:
        if pg_conn is not None:
            pg_conn.close()

        if neo4j_driver is not None:
            neo4j_driver.close()



# ============================================================
# 13. VERIFY Q7 PATHS AGAINST POSTGRESQL TRANSFERS
# ============================================================

def validate_q7_transfers(pg_conn, result):
    """
    Verify that every transfer ID in a returned Q7 path exists
    and connects the consecutive account IDs in that path.

    Returns True for a valid path and False for an invalid path.
    """
    if result is None:
        return True

    accounts = result["accounts"]
    transfer_ids = result["transfer_ids"]

    if len(accounts) != len(transfer_ids) + 1:
        return False

    if not transfer_ids:
        return False

    with pg_conn.cursor() as cur:
        cur.execute(
            """
            SELECT transfer_id, sender_id, receiver_id
            FROM transfers
            WHERE transfer_id = ANY(%s)
            """,
            (transfer_ids,),
        )
        rows = cur.fetchall()

    transfer_lookup = {
        int(transfer_id): (int(sender), int(receiver))
        for transfer_id, sender, receiver in rows
    }

    if len(transfer_lookup) != len(transfer_ids):
        return False

    for index, transfer_id in enumerate(transfer_ids):
        actual_edge = transfer_lookup.get(int(transfer_id))
        expected_edge = (
            int(accounts[index]),
            int(accounts[index + 1]),
        )

        if actual_edge != expected_edge:
            return False

    return True



# ============================================================
# 14. MAIN BENCHMARK RUNNER
# ============================================================

def main():
    print("Mobile Money Investigations — Section 7", flush=True)
    print("PostgreSQL and Neo4j concurrent load test", flush=True)
    print(f"Output folder: {OUTPUT_DIR}", flush=True)

    pg_password = getpass("PostgreSQL password: ")
    neo4j_password = getpass("Neo4j password: ")

    # Never start the timed tests if preflight fails.
    run_preflight(pg_password, neo4j_password)

    all_summaries = []
    total_tests = (
        len(ENGINES)
        * len(WORKLOADS)
        * len(CLIENT_COUNTS)
        * REPETITIONS
    )
    test_number = 0

    for engine in ENGINES:
        for workload in WORKLOADS:
            for client_count in CLIENT_COUNTS:
                for repetition in range(1, REPETITIONS + 1):
                    test_number += 1
                    print(
                        f"\nTest {test_number}/{total_tests}",
                        flush=True,
                    )

                    result = run_one_test(
                        engine=engine,
                        workload=workload,
                        client_count=client_count,
                        repetition=repetition,
                        password=(
                            pg_password
                            if engine == "PostgreSQL"
                            else neo4j_password
                        ),
                    )

                    save_repetition_output(result)
                    all_summaries.append(result["summary"])

                    # Save progress after every repetition.
                    save_csv(
                        OUTPUT_DIR / "all_repetition_summaries.csv",
                        all_summaries,
                    )

    
    
    print("\nAll benchmark repetitions finished.", flush=True)

# Summarize the three repetitions for each configuration.
    final_rows = summarize_repetitions(all_summaries)

# Generate the throughput and p95 latency plots.
    create_section7_plots(final_rows)

    print(
    f"\nRepetition summaries: "
    f"{OUTPUT_DIR / 'all_repetition_summaries.csv'}",
    flush=True,
    )
    print(
    f"Final summary: {OUTPUT_DIR / 'section7_final_summary.csv'}",
    flush=True,
    )
    print(f"Plots saved in: {OUTPUT_DIR}", flush=True)



# ============================================================
# 15. SUMMARIZE THE THREE REPETITIONS
# ============================================================

def summarize_repetitions(summaries):
    """Calculate the median metrics for each test configuration."""

    grouped = defaultdict(list)

    for row in summaries:
        key = (
            row["engine"],
            row["workload"],
            row["client_count"],
        )
        grouped[key].append(row)

    final_rows = []

    for (engine, workload, clients), repetitions in sorted(
        grouped.items()
    ):
        def median_metric(metric):
            values = [
                row[metric]
                for row in repetitions
                if row.get(metric) is not None
            ]
            return (
                round(statistics.median(values), 3)
                if values else None
            )

        final_rows.append({
            "engine": engine,
            "workload": workload,
            "client_count": clients,
            "repetitions_observed": len(repetitions),
            "median_throughput_requests_per_second":
                median_metric("throughput_requests_per_second"),
            "median_latency_ms":
                median_metric("median_latency_ms"),
            "median_p95_latency_ms":
                median_metric("p95_latency_ms"),
            "median_errors": median_metric("errors"),
            "median_timeouts": median_metric("timeouts"),
        })

    save_csv(
        OUTPUT_DIR / "section7_final_summary.csv",
        final_rows,
    )

    print("\nFinal median-of-repetitions summary:", flush=True)
    for row in final_rows:
        print(row, flush=True)

    return final_rows




# ============================================================
# 16. PLOT THROUGHPUT AND P95 LATENCY
# ============================================================

def create_section7_plots(final_rows):
    """Create throughput and p95 latency plots for Section 7.2."""

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    for workload in WORKLOADS:
        workload_rows = [
            row for row in final_rows
            if row["workload"] == workload
        ]

        # Plot throughput against the number of concurrent clients.
        fig, ax = plt.subplots()

        for engine in ENGINES:
            rows = sorted(
                [
                    row for row in workload_rows
                    if row["engine"] == engine
                ],
                key=lambda row: row["client_count"],
            )

            x = [row["client_count"] for row in rows]
            y = [
                row["median_throughput_requests_per_second"]
                for row in rows
            ]

            ax.plot(x, y, marker="o", label=engine)

        ax.set_title(f"{workload}: Throughput vs Concurrent Clients")
        ax.set_xlabel("Concurrent clients")
        ax.set_ylabel("Median throughput (requests/second)")
        ax.set_xticks(CLIENT_COUNTS)
        ax.grid(True)
        ax.legend()
        fig.tight_layout()

        throughput_path = (
            OUTPUT_DIR / f"{workload.lower()}_throughput.png"
        )
        fig.savefig(throughput_path, dpi=160)
        plt.close(fig)

        # Plot p95 latency against the number of concurrent clients.
        fig, ax = plt.subplots()

        for engine in ENGINES:
            rows = sorted(
                [
                    row for row in workload_rows
                    if row["engine"] == engine
                ],
                key=lambda row: row["client_count"],
            )

            x = [row["client_count"] for row in rows]
            y = [
                row["median_p95_latency_ms"]
                for row in rows
            ]

            ax.plot(x, y, marker="o", label=engine)

        ax.set_title(f"{workload}: p95 Latency vs Concurrent Clients")
        ax.set_xlabel("Concurrent clients")
        ax.set_ylabel("Median p95 latency (milliseconds)")
        ax.set_xticks(CLIENT_COUNTS)
        ax.grid(True)
        ax.legend()
        fig.tight_layout()

        latency_path = (
            OUTPUT_DIR / f"{workload.lower()}_p95_latency.png"
        )
        fig.savefig(latency_path, dpi=160)
        plt.close(fig)

        print(f"Saved plot: {throughput_path}", flush=True)
        print(f"Saved plot: {latency_path}", flush=True)


if __name__ == "__main__":
    mp.freeze_support()
    main()
