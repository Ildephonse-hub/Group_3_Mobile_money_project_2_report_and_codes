
import getpass
import time

import psycopg
from neo4j import GraphDatabase


# ============================================================
# Q7 — POSTGRESQL VS NEO4J
# Six start-destination pairs, two bounds: 4 and 6.
# Total: 12 shortest-length comparisons.
# ============================================================

PG_CONFIG = {
    "host": "localhost",
    "port": 5433,
    "dbname": "mobile_money_investigations",
    "user": "postgres",
}

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"

PAIRS = (
    ("A", 998, 24755),
    ("B", 147228, 186823),
    ("C", 206978, 6573),
    ("D", 237998, 21755),
    ("E", 144228, 183823),
    ("F", 203978, 3573),
)

BOUNDS = (4, 6)
# ------------------------------------------------------------
# PostgreSQL recursive search.
#
# The search follows directed transfers:
# sender_id -> receiver_id.
#
# Only person accounts may occur in the path.
# Accounts cannot repeat within one path.
# The recursive search stops at the specified bound.
# ------------------------------------------------------------

SQL_Q7 = """
WITH RECURSIVE paths AS (
    SELECT
        a.account_id AS start_account,
        t.receiver_id AS current_account,
        ARRAY[a.account_id, t.receiver_id]::integer[] AS account_path,
        ARRAY[t.transfer_id]::bigint[] AS transfer_ids,
        1 AS depth
    FROM accounts a
    JOIN transfers t
        ON t.sender_id = a.account_id
    JOIN accounts next_account
        ON next_account.account_id = t.receiver_id
       AND next_account.role = 'person'
    WHERE a.account_id = %s
      AND a.role = 'person'
      AND %s >= 1

    UNION ALL

    SELECT
        p.start_account,
        t.receiver_id,
        p.account_path || t.receiver_id,
        p.transfer_ids || t.transfer_id,
        p.depth + 1
    FROM paths p
    JOIN transfers t
        ON t.sender_id = p.current_account
    JOIN accounts next_account
        ON next_account.account_id = t.receiver_id
       AND next_account.role = 'person'
    WHERE p.depth < %s
      AND NOT t.receiver_id = ANY(p.account_path)
)
SELECT
    depth,
    account_path,
    transfer_ids
FROM paths
WHERE current_account = %s
ORDER BY depth, transfer_ids
LIMIT 1;
"""


# ------------------------------------------------------------
# Neo4j native shortest-path search.
#
# BOUND is replaced with 4 or 6 before executing.
# The role restrictions apply inside the repeated path pattern.
# ------------------------------------------------------------

CYPHER_TEMPLATE = """
MATCH p = ANY SHORTEST
    (s:Account {account_id: $start})
    ((a:Account)-[:TRANSFER]->(b:Account)
        WHERE a.role = 'person'
          AND b.role = 'person'
    ){1,BOUND}
    (d:Account {account_id: $destination})
RETURN
    length(p) AS depth,
    [n IN nodes(p) | n.account_id] AS account_path,
    [r IN relationships(p) | r.transfer_id] AS transfer_ids
"""


def normalize_path(depth, account_path, transfer_ids):
    if depth is None:
        return None

    return {
        "depth": int(depth),
        "account_path": [int(x) for x in account_path],
        "transfer_ids": [int(x) for x in transfer_ids],
    }



def get_postgres_path(pg_conn, start, destination, bound):
    """
    Find a shortest directed person-to-person transfer path
    using iterative breadth-first search (BFS).

    BFS explores paths by increasing number of transfers.
    A visited set prevents repeatedly exploring the same account.
    The search stops when the destination is discovered or
    the specified transfer bound is reached.
    """

    # Confirm the starting account exists and has the right role.
    with pg_conn.cursor() as cur:
        cur.execute(
            """
            SELECT account_id
            FROM accounts
            WHERE account_id = %s
              AND role = 'person'
            """,
            (start,),
        )
        if cur.fetchone() is None:
            return None

    # Parent records allow us to reconstruct one shortest path
    # without storing every possible path.
    parent = {start: None}
    parent_transfer = {}

    visited = {start}
    frontier = [start]

    for depth in range(1, bound + 1):
        if not frontier:
            return None

        # Fetch outgoing transfers for the current BFS level.
        # The sender index helps PostgreSQL locate these records.
        with pg_conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    t.sender_id,
                    t.receiver_id,
                    t.transfer_id
                FROM transfers t
                JOIN accounts sender
                    ON sender.account_id = t.sender_id
                   AND sender.role = 'person'
                JOIN accounts receiver
                    ON receiver.account_id = t.receiver_id
                   AND receiver.role = 'person'
                WHERE t.sender_id = ANY(%s)
                ORDER BY
                    t.sender_id,
                    t.receiver_id,
                    t.transfer_id
                """,
                (frontier,),
            )
            edges = cur.fetchall()

        next_frontier = []

        for sender_id, receiver_id, transfer_id in edges:
            sender_id = int(sender_id)
            receiver_id = int(receiver_id)
            transfer_id = int(transfer_id)

            # Do not revisit an account already reached by a
            # shorter or equally short BFS route.
            if receiver_id in visited:
                continue

            visited.add(receiver_id)
            parent[receiver_id] = sender_id
            parent_transfer[receiver_id] = transfer_id
            next_frontier.append(receiver_id)

            # The first discovery is a shortest path because
            # BFS processes one transfer level at a time.
            if receiver_id == destination:
                account_path = [destination]
                transfer_ids = []
                current = destination

                while current != start:
                    transfer_ids.append(parent_transfer[current])
                    current = parent[current]
                    account_path.append(current)

                account_path.reverse()
                transfer_ids.reverse()

                return {
                    "depth": len(transfer_ids),
                    "account_path": account_path,
                    "transfer_ids": transfer_ids,
                }

        frontier = next_frontier

    # No route was found within the requested bound.
    return None


def get_neo4j_path(driver, start, destination, bound):
    query = CYPHER_TEMPLATE.replace("BOUND", str(bound))

    with driver.session(database="neo4j") as session:
        result = session.run(
            query,
            start=start,
            destination=destination,
        )
        record = result.single()

    if record is None:
        return None

    return normalize_path(
        record["depth"],
        record["account_path"],
        record["transfer_ids"],
    )


def validate_path_against_postgres(
    pg_conn, path, start, destination, bound
):
    """
    Validate a returned path using PostgreSQL source records.

    Checks:
    - expected start and destination
    - path length within the requested bound
    - account count equals transfer count + 1
    - all accounts exist and have role 'person'
    - no repeated accounts
    - every transfer event exists
    - each transfer follows the direction in the path
    """
    errors = []

    if path is None:
        return False, ["There is no supporting path to validate."]

    depth = path["depth"]
    accounts = path["account_path"]
    transfer_ids = path["transfer_ids"]

    if depth < 1 or depth > bound:
        errors.append(
            f"Path length {depth} is outside the allowed range 1..{bound}."
        )

    if len(accounts) != depth + 1:
        errors.append("Account count must equal path length + 1.")

    if len(transfer_ids) != depth:
        errors.append("Transfer ID count must equal path length.")

    if not accounts or accounts[0] != start:
        errors.append(f"Path does not start at account {start}.")

    if not accounts or accounts[-1] != destination:
        errors.append(f"Path does not end at account {destination}.")

    if len(accounts) != len(set(accounts)):
        errors.append("Path repeats an account.")

    with pg_conn.cursor() as cur:
        # Verify all accounts and their roles.
        if accounts:
            cur.execute(
                """
                SELECT account_id, role
                FROM accounts
                WHERE account_id = ANY(%s)
                """,
                (accounts,),
            )
            roles = {
                int(account_id): role
                for account_id, role in cur.fetchall()
            }

            for account_id in accounts:
                if account_id not in roles:
                    errors.append(
                        f"Account {account_id} does not exist in PostgreSQL."
                    )
                elif roles[account_id] != "person":
                    errors.append(
                        f"Account {account_id} has role "
                        f"{roles[account_id]!r}, not 'person'."
                    )

        # Verify transfer existence and directed sender/receiver pairs.
        if len(accounts) == len(transfer_ids) + 1:
            for index, transfer_id in enumerate(transfer_ids):
                expected_sender = accounts[index]
                expected_receiver = accounts[index + 1]

                cur.execute(
                    """
                    SELECT sender_id, receiver_id
                    FROM transfers
                    WHERE transfer_id = %s
                    """,
                    (transfer_id,),
                )
                event = cur.fetchone()

                if event is None:
                    errors.append(
                        f"Transfer event {transfer_id} does not exist."
                    )
                elif (
                    int(event[0]) != expected_sender
                    or int(event[1]) != expected_receiver
                ):
                    errors.append(
                        f"Transfer {transfer_id} direction mismatch: "
                        f"expected {expected_sender}->{expected_receiver}; "
                        f"found {event[0]}->{event[1]}."
                    )

    return not errors, errors


def print_path(label, path):
    print(f"  {label}:")

    if path is None:
        print("    No route found within this bound.")
        return

    print(f"    Shortest length: {path['depth']}")
    print(f"    Account path:    {path['account_path']}")
    print(f"    Transfer IDs:    {path['transfer_ids']}")


def compare_case(pg_conn, driver, case_id, start, destination, bound):
    print("\n" + "=" * 72)
    print(
        f"Q7 Case {case_id}: {start} -> {destination}; "
        f"maximum length = {bound}"
    )
    print("=" * 72)

    started = time.perf_counter()

    print("Searching PostgreSQL...")
    pg_path = get_postgres_path(
        pg_conn, start, destination, bound
    )
    print_path("PostgreSQL", pg_path)

    print("\nSearching Neo4j...")
    neo_path = get_neo4j_path(
        driver, start, destination, bound
    )
    print_path("Neo4j", neo_path)

    # Compare shortest lengths / no-route outcomes.
    if pg_path is None and neo_path is None:
        comparison_pass = True
        print("\nLength comparison: PASS — neither database found a route.")
    elif pg_path is None or neo_path is None:
        comparison_pass = False
        print(
            "\nLength comparison: FAIL — one database found a route "
            "and the other did not."
        )
    elif pg_path["depth"] == neo_path["depth"]:
        comparison_pass = True
        print(
            "\nLength comparison: PASS — both found shortest length "
            f"{pg_path['depth']}."
        )

        if pg_path["transfer_ids"] != neo_path["transfer_ids"]:
            print(
                "Note: Transfer IDs differ. Equally short valid routes "
                "may differ between databases."
            )
    else:
        comparison_pass = False
        print(
            "\nLength comparison: FAIL — PostgreSQL length "
            f"{pg_path['depth']} versus Neo4j length {neo_path['depth']}."
        )

    # Validate supporting paths independently against PostgreSQL data.
    validation_results = []

    print("\nSupporting-path validation:")

    if pg_path is not None:
        valid, errors = validate_path_against_postgres(
            pg_conn, pg_path, start, destination, bound
        )
        validation_results.append(valid)
        print(f"  PostgreSQL path: {'PASS' if valid else 'FAIL'}")
        for error in errors:
            print(f"    - {error}")
    else:
        print("  PostgreSQL path: NOT APPLICABLE (no route returned)")

    if neo_path is not None:
        valid, errors = validate_path_against_postgres(
            pg_conn, neo_path, start, destination, bound
        )
        validation_results.append(valid)
        print(f"  Neo4j path:      {'PASS' if valid else 'FAIL'}")
        for error in errors:
            print(f"    - {error}")
    else:
        print("  Neo4j path:      NOT APPLICABLE (no route returned)")

    elapsed = time.perf_counter() - started

    print(f"\nElapsed time: {elapsed:.2f} seconds")

    return {
        "case": case_id,
        "start": start,
        "destination": destination,
        "bound": bound,
        "pg_length": None if pg_path is None else pg_path["depth"],
        "neo_length": None if neo_path is None else neo_path["depth"],
        "comparison_pass": comparison_pass,
        "validation_pass": all(validation_results),
    }


def main():
    pg_password = getpass.getpass("PostgreSQL password: ")
    neo4j_password = getpass.getpass("Neo4j password: ")

    pg_conn = None
    driver = None
    results = []

    try:
        print("\nConnecting to PostgreSQL...")
        pg_conn = psycopg.connect(
            **PG_CONFIG,
            password=pg_password,
            connect_timeout=10,
        )
        print("PostgreSQL connection: OK")

        print("\nConnecting to Neo4j...")
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USER, neo4j_password),
        )
        driver.verify_connectivity()
        print("Neo4j connection: OK")

        print("\nStarting Q7 tests: 6 pairs x 2 bounds = 12 comparisons.")

        for case_id, start, destination in PAIRS:
            for bound in BOUNDS:
                result = compare_case(
                    pg_conn,
                    driver,
                    case_id,
                    start,
                    destination,
                    bound,
                )
                results.append(result)

        # Summary
        print("\n\n" + "#" * 72)
        print("Q7 SUMMARY")
        print("#" * 72)

        print(
            f"{'Case':<6}{'Start':>10}{'Destination':>14}"
            f"{'Bound':>8}{'PG length':>12}{'Neo length':>12}"
            f"{'Compare':>12}{'Paths':>10}"
        )
        print("-" * 84)

        for row in results:
            pg_len = (
                "NONE" if row["pg_length"] is None
                else str(row["pg_length"])
            )
            neo_len = (
                "NONE" if row["neo_length"] is None
                else str(row["neo_length"])
            )

            print(
                f"{row['case']:<6}"
                f"{row['start']:>10}"
                f"{row['destination']:>14}"
                f"{row['bound']:>8}"
                f"{pg_len:>12}"
                f"{neo_len:>12}"
                f"{('PASS' if row['comparison_pass'] else 'FAIL'):>12}"
                f"{('PASS' if row['validation_pass'] else 'FAIL'):>10}"
            )

        comparison_count = len(results)
        comparison_passes = sum(
            row["comparison_pass"] for row in results
        )
        validation_passes = sum(
            row["validation_pass"] for row in results
        )

        print("-" * 84)
        print(
            f"Shortest-length comparisons: "
            f"{comparison_passes}/{comparison_count} PASS"
        )
        print(
            f"Supporting-path validation: "
            f"{validation_passes}/{comparison_count} PASS"
        )

        if comparison_passes == comparison_count:
            print("All Q7 shortest-length comparisons PASS.")
        else:
            print("Some Q7 shortest-length comparisons FAILED.")

        if validation_passes == comparison_count:
            print("All applicable supporting-path validations PASS.")
        else:
            print("Some supporting-path validations FAILED.")

        print(
            "\nImportant: no route within bound 4 does not prove "
            "that no route exists at greater lengths."
        )
        print(
            "A structural transfer path alone does not prove that "
            "funds moved onward in chronological order."
        )

    except Exception as exc:
        print("\nERROR while running Q7 tests:")
        print(f"{type(exc).__name__}: {exc}")
        print(
            "\nThe test stopped. Share the complete error output "
            "before changing the queries."
        )

    finally:
        if driver is not None:
            driver.close()
            print("\nNeo4j connection closed.")

        if pg_conn is not None:
            pg_conn.close()
            print("PostgreSQL connection closed.")


if __name__ == "__main__":
    main()
