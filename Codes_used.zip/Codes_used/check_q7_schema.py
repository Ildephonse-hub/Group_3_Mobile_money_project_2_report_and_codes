from getpass import getpass
from neo4j import GraphDatabase

password = getpass("Neo4j password: ")

driver = GraphDatabase.driver(
    "bolt://localhost:7687",
    auth=("neo4j", password),
)

try:
    with driver.session(database="neo4j") as session:
        result = session.run("""
            MATCH (a:Account)-[r:TRANSFER]->(b:Account)
            RETURN
                keys(r) AS relationship_properties,
                a.role AS sender_role,
                b.role AS receiver_role,
                r.transfer_id AS transfer_id,
                r.occurred_at AS occurred_at
            LIMIT 5
        """)

        for record in result:
            print(record.data())
finally:
    driver.close()
    print("Connection closed.")