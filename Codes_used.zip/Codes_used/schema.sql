
-- Q2.1: Define the five PostgreSQL tables
-- Database: mobile_money_investigations
-- All columns are NOT NULL.

CREATE TABLE customers (
    customer_id INTEGER NOT NULL,
    region TEXT NOT NULL,
    CONSTRAINT customers_pkey PRIMARY KEY (customer_id)
);

CREATE TABLE devices (
    device_id INTEGER NOT NULL,
    access_type TEXT NOT NULL,
    CONSTRAINT devices_pkey PRIMARY KEY (device_id)
);

CREATE TABLE accounts (
    account_id INTEGER NOT NULL,
    customer_id INTEGER NOT NULL,
    role TEXT NOT NULL,

    CONSTRAINT accounts_pkey PRIMARY KEY (account_id),

    CONSTRAINT accounts_customer_fk
        FOREIGN KEY (customer_id)
        REFERENCES customers (customer_id)
);

CREATE TABLE account_devices (
    account_id INTEGER NOT NULL,
    device_id INTEGER NOT NULL,
    first_day SMALLINT NOT NULL,
    last_day SMALLINT NOT NULL,
    observations INTEGER NOT NULL,

    CONSTRAINT account_devices_pkey
        PRIMARY KEY (account_id, device_id),

    CONSTRAINT account_devices_account_fk
        FOREIGN KEY (account_id)
        REFERENCES accounts (account_id),

    CONSTRAINT account_devices_device_fk
        FOREIGN KEY (device_id)
        REFERENCES devices (device_id),

    CONSTRAINT account_devices_observations_positive
        CHECK (observations > 0),

    CONSTRAINT account_devices_days_valid
        CHECK (
            first_day >= 0
            AND first_day <= last_day
            AND last_day <= 29
        )
);

CREATE TABLE transfers (
    transfer_id BIGINT NOT NULL,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    occurred_at BIGINT NOT NULL,
    amount_rwf INTEGER NOT NULL,

    CONSTRAINT transfers_pkey PRIMARY KEY (transfer_id),

    CONSTRAINT transfers_sender_fk
        FOREIGN KEY (sender_id)
        REFERENCES accounts (account_id),

    CONSTRAINT transfers_receiver_fk
        FOREIGN KEY (receiver_id)
        REFERENCES accounts (account_id),

    CONSTRAINT transfers_amount_positive
        CHECK (amount_rwf > 0)
);
