
from neo4j import GraphDatabase
from getpass import getpass
import csv
import time

URI = "bolt://localhost:7687"
DATABASE = "neo4j"
BATCH_SIZE = 100_000

username = input("Neo4j username [neo4j]: ").strip() or "neo4j"
password = getpass("Neo4j password: ")

driver = GraphDatabase.driver(
    URI,
    auth=(username, password)
)

summary_file = "transfer_uniqueness_summary.csv"
duplicates_file = "duplicate_transfer_ids.csv"


def read_bounds(session):
    return session.run("""
        MATCH ()-[t:TRANSFER]->()
        RETURN
            count(t) AS total_relationships,
            count(t.transfer_id) AS ids_present,
            min(t.transfer_id) AS min_id,
            max(t.transfer_id) AS max_id
    """).single()


def check_batch(session, start_id, end_id):
    return session.run("""
        MATCH ()-[t:TRANSFER]->()
        WHERE t.transfer_id >= $start_id
          AND t.transfer_id <= $end_id
        WITH t.transfer_id AS transfer_id,
             count(*) AS occurrences
        RETURN
            sum(occurrences) AS relationships_checked,
            sum(CASE WHEN occurrences > 1
                THEN 1 ELSE 0 END) AS duplicated_ids,
            sum(CASE WHEN occurrences > 1
                THEN occurrences - 1 ELSE 0 END)
                AS extra_relationships
    """, start_id=start_id, end_id=end_id).single()


def find_duplicate_details(session, start_id, end_id):
    return session.run("""
        MATCH ()-[t:TRANSFER]->()
        WHERE t.transfer_id >= $start_id
          AND t.transfer_id <= $end_id
        WITH t.transfer_id AS transfer_id,
             count(*) AS occurrences
        WHERE occurrences > 1
        RETURN transfer_id, occurrences
        ORDER BY transfer_id
    """, start_id=start_id, end_id=end_id)


try:
    driver.verify_connectivity()
    print("\nConnected to Neo4j successfully.")

    with driver.session(database=DATABASE) as session:
        bounds = read_bounds(session)

        total = bounds["total_relationships"]
        ids_present = bounds["ids_present"]
        min_id = bounds["min_id"]
        max_id = bounds["max_id"]

        print(f"Total TRANSFER relationships: {total:,}")
        print(f"Relationships with transfer IDs: {ids_present:,}")
        print(f"Minimum transfer ID: {min_id}")
        print(f"Maximum transfer ID: {max_id}")

        if total == 0:
            print("No TRANSFER relationships found.")
            raise SystemExit(1)

        if ids_present != total:
            print("WARNING: Some transfers have missing transfer_id values.")
            print("These records require separate investigation.")

        if min_id is None or max_id is None:
            print("Cannot run range checks: no usable transfer IDs.")
            raise SystemExit(1)

        if not isinstance(min_id, int) or not isinstance(max_id, int):
            print("Transfer IDs are not integers. Stop and investigate.")
            raise SystemExit(1)

        if min_id > max_id:
            print("Invalid transfer ID range.")
            raise SystemExit(1)

        checked = 0
        duplicate_id_count = 0
        extra_relationship_count = 0
        batch_number = 0
        started = time.time()

        with open(summary_file, "w", newline="",
                  encoding="utf-8") as summary, \
             open(duplicates_file, "w", newline="",
                  encoding="utf-8") as duplicate_output:

            summary_writer = csv.writer(summary)
            duplicate_writer = csv.writer(duplicate_output)

            summary_writer.writerow([
                "start_id", "end_id", "relationships_checked",
                "duplicated_ids", "extra_relationships"
            ])

            duplicate_writer.writerow([
                "transfer_id", "occurrences"
            ])

            start_id = min_id

            while start_id <= max_id:
                end_id = min(start_id + BATCH_SIZE - 1, max_id)

                result = check_batch(session, start_id, end_id)

                batch_checked = result["relationships_checked"] or 0
                batch_duplicates = result["duplicated_ids"] or 0
                batch_extras = result["extra_relationships"] or 0

                checked += batch_checked
                duplicate_id_count += batch_duplicates
                extra_relationship_count += batch_extras
                batch_number += 1

                summary_writer.writerow([
                    start_id, end_id, batch_checked,
                    batch_duplicates, batch_extras
                ])
                summary.flush()

                if batch_duplicates:
                    for record in find_duplicate_details(
                        session, start_id, end_id
                    ):
                        duplicate_writer.writerow([
                            record["transfer_id"],
                            record["occurrences"]
                        ])
                    duplicate_output.flush()

                print(
                    f"Batch {batch_number}: "
                    f"{start_id:,}-{end_id:,} | "
                    f"checked={batch_checked:,} | "
                    f"duplicate IDs={batch_duplicates:,} | "
                    f"extra relationships={batch_extras:,}"
                )

                start_id = end_id + 1

        elapsed = time.time() - started

        print("\n--- VERIFICATION SUMMARY ---")
        print(f"Relationships counted in batches: {checked:,}")
        print(f"Total relationships in database: {total:,}")
        print(f"Duplicate IDs found: {duplicate_id_count:,}")
        print(f"Extra relationships: {extra_relationship_count:,}")
        print(f"Missing transfer IDs: {total - ids_present:,}")
        print(f"Elapsed time: {elapsed / 60:.2f} minutes")
        print(f"Batch report: {summary_file}")
        print(f"Duplicate details: {duplicates_file}")

        if checked != ids_present:
            print("RESULT: INCOMPLETE — batch count does not match.")
        elif ids_present != total:
            print("RESULT: INCOMPLETE — some transfer IDs are missing.")
        elif duplicate_id_count != 0:
            print("RESULT: DUPLICATES FOUND — inspect the CSV report.")
        else:
            print(
                "RESULT: PASS — every transfer has an ID, "
                "and all IDs are unique within the checked data."
            )

finally:
    driver.close()
