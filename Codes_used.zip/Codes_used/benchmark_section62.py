
"""
Section 6.2 — PostgreSQL vs Neo4j query timing.
Reuses the verified queries and Q7 path functions from compare_section6.py.
Does not modify the verification script or database data.
"""

import csv
import statistics
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from getpass import getpass

import psycopg
from neo4j import GraphDatabase

import compare_section6 as base


# ------------------------------------------------------------
# Benchmark configuration
# ------------------------------------------------------------

OUTPUT = Path("section62_benchmark_results.csv")
TZ = ZoneInfo("Africa/Kigali")

WARMUPS = 3
MEASURED_RUNS = 5
WARMUP_TIMEOUT_SECONDS = 180
MEASURED_TIMEOUT_SECONDS = 60

# Required cases: 21 per database engine.
SELECTED_CASES = {
    "B": (147228, 13),
    "E": (144228, 13),
}

Q4_DEPTHS = (4, 6, 8, 10)
Q7_BOUNDS = (4, 6)


def cat_now():
    return datetime.now(TZ).isoformat(timespec="seconds")


def september_bounds():
    return base.september_epoch_bounds()


def make_cases():
    cases = []

    # Q1: two selected review cases.
    for label, (account, day) in SELECTED_CASES.items():
        start, end = base.q1_epoch_bounds(day)
        cases.append({
            "case_id": f"Q1_{label}",
            "question": "Q1",
            "parameters": f"case={label};account={account};day={day}",
            "pg_query": base.SQL_Q1,
            "pg_params": (start, end, account),
            "neo_query": base.CYPHER_Q1,
            "neo_params": {
                "account": account,
                "start_epoch": start,
                "end_epoch": end,
            },
        })

    # Q2: full September 2026.
    start, end = september_bounds()
    cases.append({
        "case_id": "Q2_FULL_MONTH",
        "question": "Q2",
        "parameters": "2026-09-01 through 2026-09-30 CAT",
        "pg_query": base.SQL_Q2,
        "pg_params": (start, end),
        "neo_query": base.CYPHER_Q2,
        "neo_params": {
            "start_epoch": start,
            "end_epoch": end,
        },
    })

    # Q3: two selected cases.
    for label, (account, _day) in SELECTED_CASES.items():
        cases.append({
            "case_id": f"Q3_{label}",
            "question": "Q3",
            "parameters": f"case={label};account={account}",
            "pg_query": base.SQL_Q3,
            "pg_params": (account,),
            "neo_query": base.CYPHER_Q3,
            "neo_params": {"account": account},
        })

    # Q4: two cases at four traversal depths.
    for label, (account, _day) in SELECTED_CASES.items():
        for depth in Q4_DEPTHS:
            cases.append({
                "case_id": f"Q4_{label}_D{depth}",
                "question": "Q4",
                "parameters": (
                    f"case={label};account={account};depth={depth}"
                ),
                "pg_query": base.SQL_Q4,
                "pg_params": (account, depth, depth, account),
                "neo_query": base.cypher_q4(depth),
                "neo_params": {"account": account},
            })

    # Q5: two selected cases.
    for label, (account, day) in SELECTED_CASES.items():
        start, end = base.q1_epoch_bounds(day)
        cases.append({
            "case_id": f"Q5_{label}",
            "question": "Q5",
            "parameters": f"case={label};account={account};day={day}",
            "pg_query": base.SQL_Q5,
            "pg_params": (account, start, end),
            "neo_query": base.CYPHER_Q5,
            "neo_params": {
                "account": account,
                "start_epoch": start,
                "end_epoch": end,
            },
        })

    # Q6: two selected cases.
    for label, (account, day) in SELECTED_CASES.items():
        start, end = base.q1_epoch_bounds(day)
        cases.append({
            "case_id": f"Q6_{label}",
            "question": "Q6",
            "parameters": f"case={label};account={account};day={day}",
            "pg_query": base.SQL_Q6,
            "pg_params": (account, start, end, end),
            "neo_query": base.CYPHER_Q6,
            "neo_params": {
                "account": account,
                "start_epoch": start,
                "end_epoch": end,
            },
        })

    # Q7: two account pairs at both search bounds.
    for label, (start_account, destination) in {
        "B": (147228, 186823),
        "E": (144228, 183823),
    }.items():
        for bound in Q7_BOUNDS:
            cases.append({
                "case_id": f"Q7_{label}_B{bound}",
                "question": "Q7",
                "parameters": (
                    f"case={label};start={start_account};"
                    f"destination={destination};bound={bound}"
                ),
                "q7": True,
                "start_account": start_account,
                "destination": destination,
                "bound": bound,
            })

    if len(cases) != 21:
        raise RuntimeError(
            f"Expected 21 benchmark cases, found {len(cases)}"
        )

    return cases


def execute_pg(pg, case, timeout_seconds):
    """
    Execute one query and consume every returned row.
    Q7 uses the existing iterative BFS function. Its individual SQL
    statements receive the configured PostgreSQL statement timeout.
    """
    with pg.cursor() as cur:
        cur.execute(
            "SELECT set_config('statement_timeout', %s, true)",
            (f"{int(timeout_seconds * 1000)}ms",),
        )

    if case.get("q7"):
        result = base.get_postgres_path(
            pg,
            case["start_account"],
            case["destination"],
            case["bound"],
        )
        return 0 if result is None else 1

    with pg.cursor() as cur:
        cur.execute(case["pg_query"], case["pg_params"])
        rows = cur.fetchall()
        return len(rows)


def execute_neo(session, case, timeout_seconds):
    """
    Run inside an explicit transaction with a transaction timeout,
    then consume all rows before returning.
    """
    with session.begin_transaction(timeout=timeout_seconds) as tx:
        if case.get("q7"):
            result = base.get_neo4j_path(
                tx,
                case["start_account"],
                case["destination"],
                case["bound"],
            )
            return 0 if result is None else 1

        result = tx.run(case["neo_query"], case["neo_params"])
        rows = list(result)
        return len(rows)


def append_result(writer, file_handle, case, engine, phase,
                  run_number, started_at, duration_ms, row_count,
                  status, error_message=""):
    writer.writerow({
        "case_id": case["case_id"],
        "question": case["question"],
        "parameters": case["parameters"],
        "engine": engine,
        "phase": phase,
        "run_number": run_number,
        "started_at_cat": started_at,
        "duration_ms": (
            f"{duration_ms:.3f}" if duration_ms is not None else ""
        ),
        "row_count": row_count if row_count is not None else "",
        "status": status,
        "error": error_message,
    })
    file_handle.flush()


def run_one(writer, file_handle, pg, neo, case, engine, phase, run_number):
    timeout = (
        WARMUP_TIMEOUT_SECONDS
        if phase == "warmup"
        else MEASURED_TIMEOUT_SECONDS
    )

    started_at = cat_now()
    start_clock = time.perf_counter()

    try:
        if engine == "PostgreSQL":
            row_count = execute_pg(pg, case, timeout)
        else:
            row_count = execute_neo(neo, case, timeout)

        elapsed_ms = (time.perf_counter() - start_clock) * 1000

        append_result(
            writer, file_handle, case, engine, phase, run_number,
            started_at, elapsed_ms, row_count, "OK",
        )
        print(
            f"{engine:10} {case['case_id']:16} {phase:7} "
            f"{run_number} {elapsed_ms:10.3f} ms rows={row_count}"
        )
        return elapsed_ms

    except Exception as exc:
        elapsed_ms = (time.perf_counter() - start_clock) * 1000

        # Roll back any failed PostgreSQL transaction before continuing.
        if engine == "PostgreSQL":
            try:
                pg.rollback()
            except Exception:
                pass

        message = f"{type(exc).__name__}: {exc}"
        status = (
            "TIMEOUT"
            if "timeout" in message.lower()
            or "timed out" in message.lower()
            else "ERROR"
        )

        append_result(
            writer, file_handle, case, engine, phase, run_number,
            started_at, elapsed_ms, None, status, message,
        )
        print(
            f"{engine:10} {case['case_id']:16} {phase:7} "
            f"{run_number} {status}: {message}"
        )
        return None


def main():
    print("Section 6.2 benchmark")
    print("Cases: 21 per engine")
    print("Warm-ups: 3 per case/engine")
    print("Measured runs: 5 per case/engine")
    print("Results file:", OUTPUT.resolve())
    print()

    pg_password = getpass("PostgreSQL password for postgres: ")
    neo_password = getpass("Neo4j password for neo4j: ")

    pg = None
    driver = None

    summaries = []

    try:
        pg = psycopg.connect(
            host=base.PG_HOST,
            port=base.PG_PORT,
            dbname=base.PG_DATABASE,
            user=base.PG_USER,
            password=pg_password,
            connect_timeout=10,
        )

        driver = GraphDatabase.driver(
            base.NEO4J_URI,
            auth=(base.NEO4J_USER, neo_password),
        )
        driver.verify_connectivity()

        cases = make_cases()

        with driver.session(database=base.NEO4J_DATABASE) as neo:
            with OUTPUT.open(
                "w", newline="", encoding="utf-8-sig"
            ) as file_handle:
                fieldnames = [
                    "case_id", "question", "parameters", "engine",
                    "phase", "run_number", "started_at_cat",
                    "duration_ms", "row_count", "status", "error",
                ]
                writer = csv.DictWriter(
                    file_handle, fieldnames=fieldnames
                )
                writer.writeheader()
                file_handle.flush()

                # Run each engine separately for each case to avoid
                # simultaneous query execution across the two databases.
                for case in cases:
                    for engine in ("PostgreSQL", "Neo4j"):
                        print(f"\n=== {case['case_id']} | {engine} ===")

                        # Three warm-ups; warm-up timings are not used
                        # in the final medians.
                        for i in range(1, WARMUPS + 1):
                            run_one(
                                writer, file_handle, pg, neo, case,
                                engine, "warmup", i,
                            )

                        # Five measured runs.
                        successful = []
                        for i in range(1, MEASURED_RUNS + 1):
                            value = run_one(
                                writer, file_handle, pg, neo, case,
                                engine, "measured", i,
                            )
                            if value is not None:
                                # Only successful measurements count.
                                # Failed/timeout runs remain in the CSV.
                                successful.append(value)

                        summaries.append({
                            "case_id": case["case_id"],
                            "engine": engine,
                            "successful_runs": len(successful),
                            "median_ms": (
                                statistics.median(successful)
                                if successful else None
                            ),
                            "min_ms": min(successful) if successful else None,
                            "max_ms": max(successful) if successful else None,
                        })

        print("\n=== MEDIAN / MIN / MAX SUMMARY ===")
        for item in summaries:
            if item["median_ms"] is None:
                print(
                    f"{item['case_id']:16} {item['engine']:10} "
                    f"successful={item['successful_runs']}/5 "
                    "NO SUCCESSFUL MEASUREMENTS"
                )
            else:
                print(
                    f"{item['case_id']:16} {item['engine']:10} "
                    f"successful={item['successful_runs']}/5 "
                    f"median={item['median_ms']:.3f} ms "
                    f"min={item['min_ms']:.3f} ms "
                    f"max={item['max_ms']:.3f} ms"
                )

        # Separate summary CSV for easy reporting.
        summary_file = Path("section62_benchmark_summary.csv")
        with summary_file.open(
            "w", newline="", encoding="utf-8-sig"
        ) as handle:
            fields = [
                "case_id", "engine", "successful_runs",
                "median_ms", "min_ms", "max_ms",
            ]
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(summaries)

        print("\nDetailed results:", OUTPUT.resolve())
        print("Summary results: ", summary_file.resolve())

    finally:
        if pg is not None:
            pg.close()
        if driver is not None:
            driver.close()
        print("\nDatabase connections closed.")


if __name__ == "__main__":
    main()
