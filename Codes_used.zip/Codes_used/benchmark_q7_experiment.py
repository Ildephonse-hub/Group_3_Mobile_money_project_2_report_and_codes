
import statistics
import time
from getpass import getpass

import psycopg

import compare_section6 as original
import compare_section6_q7_experiment as experiment


CASES = [
    ("B", 147228, 186823, 4),
    ("B", 147228, 186823, 6),
    ("E", 144228, 183823, 4),
    ("E", 144228, 183823, 6),
]

WARMUPS = 3
REPEATS = 5


def run_case(module, pg, start, destination, bound):
    return module.get_postgres_path(pg, start, destination, bound)


def expected_depth(case, bound):
    # Assignment verification established these shortest-path outcomes.
    if bound == 4:
        return None
    return 5


def main():
    password = getpass("PostgreSQL password for postgres: ")

    results = []

    try:
        with psycopg.connect(
            host=original.PG_HOST,
            port=original.PG_PORT,
            dbname=original.PG_DATABASE,
            user=original.PG_USER,
            password=password,
            connect_timeout=10,
        ) as pg:

            versions = [
                ("Original", original),
                ("Experimental", experiment),
            ]

            for version_name, module in versions:
                for case, start, destination, bound in CASES:
                    label = f"{case}_B{bound}"
                    expected = expected_depth(case, bound)

                    print(f"\n{version_name}: {label}")

                    # Warm-up runs are excluded from timing.
                    for _ in range(WARMUPS):
                        path = run_case(
                            module, pg, start, destination, bound
                        )
                        actual = None if path is None else path["depth"]
                        if actual != expected:
                            raise AssertionError(
                                f"{version_name} {label}: "
                                f"expected depth {expected}, got {actual}"
                            )

                    times_ms = []

                    for run_number in range(1, REPEATS + 1):
                        start_time = time.perf_counter()

                        path = run_case(
                            module, pg, start, destination, bound
                        )

                        elapsed_ms = (
                            time.perf_counter() - start_time
                        ) * 1000

                        actual = None if path is None else path["depth"]
                        if actual != expected:
                            raise AssertionError(
                                f"{version_name} {label}: "
                                f"expected depth {expected}, got {actual}"
                            )

                        times_ms.append(elapsed_ms)
                        print(
                            f"  Run {run_number}: "
                            f"{elapsed_ms:.3f} ms"
                        )

                    median_ms = statistics.median(times_ms)
                    results.append(
                        (version_name, label, median_ms, times_ms)
                    )
                    print(f"  Median: {median_ms:.3f} ms")

        print("\n" + "=" * 72)
        print("Q7 BFS BENCHMARK SUMMARY")
        print("=" * 72)
        print(f"{'Version':<15} {'Case':<10} {'Median (ms)':>14}")
        print("-" * 42)

        for version_name, label, median_ms, _ in results:
            print(f"{version_name:<15} {label:<10} {median_ms:>14.3f}")

        print("\nExperimental vs original:")
        for _, label, _, _ in results:
            original_median = next(
                median for version, case_label, median, _ in results
                if version == "Original" and case_label == label
            )
            experimental_median = next(
                median for version, case_label, median, _ in results
                if version == "Experimental" and case_label == label
            )

            change_pct = (
                (experimental_median - original_median)
                / original_median
                * 100
            )

            print(
                f"  {label}: {change_pct:+.2f}% runtime change "
                f"(negative means faster)"
            )

    finally:
        print("\nBenchmark finished.")


if __name__ == "__main__":
    main()

