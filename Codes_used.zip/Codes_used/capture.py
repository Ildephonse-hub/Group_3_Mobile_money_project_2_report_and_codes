

#Q1.2: Capture the five mobile-money streams into CSV files.

#The supplied mobile_money_generator.py is imported unchanged.
#Rows are written progressively; the full dataset is never held in memory.


import csv
import json
import time
from pathlib import Path
from datetime import datetime, timezone, timedelta

import mobile_money_generator as g


# ---------------------------------------------------------
# 1. Output folder and expected row counts
# ---------------------------------------------------------

OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

EXPECTED_COUNTS = g.dataset_info()["expected_counts"]

STREAMS = {
    "customers": g.iter_customers,
    "accounts": g.iter_accounts,
    "devices": g.iter_devices,
    "account_devices": g.iter_account_devices,
    "transfers": g.iter_transfers,
}

# Rwanda uses CAT (UTC+02:00).
CAT = timezone(timedelta(hours=2))


# ---------------------------------------------------------
# 2. Capture one stream into its own CSV file
# ---------------------------------------------------------

def capture_stream(name, iterator_factory):
    csv_path = OUTPUT_DIR / f"{name}.csv"

    consumed = 0
    written = 0
    start = time.perf_counter()

    transfer_count = 0
    earliest_occurred_at = None
    latest_occurred_at = None
    amount_sum_rwf = 0

    # Open one CSV file at a time and write its header.
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=g.FIELDS[name],
            extrasaction="raise",
        )
        writer.writeheader()

        # Each generator yields one dictionary at a time.
        for row in iterator_factory():
            consumed += 1

            # Write the current row immediately.
            writer.writerow(row)
            written += 1

            # Additional audit calculations for transfers only.
            if name == "transfers":
                occurred = int(row["occurred_at"])
                amount = int(row["amount_rwf"])

                transfer_count += 1
                amount_sum_rwf += amount

                if (
                    earliest_occurred_at is None
                    or occurred < earliest_occurred_at
                ):
                    earliest_occurred_at = occurred

                if (
                    latest_occurred_at is None
                    or occurred > latest_occurred_at
                ):
                    latest_occurred_at = occurred

                # Show progress after every million transfers.
                if transfer_count % 1_000_000 == 0:
                    elapsed = time.perf_counter() - start
                    print(
                        f"[transfers] {transfer_count:,} written; "
                        f"elapsed {elapsed:.1f} seconds",
                        flush=True,
                    )

    elapsed_seconds = time.perf_counter() - start
    file_size_bytes = csv_path.stat().st_size

    expected = EXPECTED_COUNTS[name]

    result = {
        "stream": name,
        "expected_rows": expected,
        "consumed_rows": consumed,
        "written_rows": written,
        "count_matches": consumed == expected and written == expected,
        "capture_seconds": round(elapsed_seconds, 3),
        "csv_size_bytes": file_size_bytes,
        "csv_size_MB": round(file_size_bytes / 1_000_000, 3),
    }

    if name == "transfers":
        result.update({
            "transfer_count": transfer_count,
            "earliest_occurred_at_unix": earliest_occurred_at,
            "latest_occurred_at_unix": latest_occurred_at,
            "earliest_occurred_at_CAT": (
                datetime.fromtimestamp(earliest_occurred_at, CAT).isoformat()
                if earliest_occurred_at is not None else None
            ),
            "latest_occurred_at_CAT": (
                datetime.fromtimestamp(latest_occurred_at, CAT).isoformat()
                if latest_occurred_at is not None else None
            ),
            "sum_amount_rwf": amount_sum_rwf,
        })

    print("\nStream finished:")
    print(json.dumps(result, indent=2))

    return result


# ---------------------------------------------------------
# 3. Capture all five streams and save an audit report
# ---------------------------------------------------------

def main():
    overall_start = time.perf_counter()
    results = []

    print("Dataset information:")
    print(json.dumps(g.dataset_info(), indent=2))

    for name, iterator_factory in STREAMS.items():
        print(f"\nStarting {name} capture...", flush=True)
        results.append(capture_stream(name, iterator_factory))

    total_seconds = time.perf_counter() - overall_start

    total_expected = sum(item["expected_rows"] for item in results)
    total_consumed = sum(item["consumed_rows"] for item in results)
    total_written = sum(item["written_rows"] for item in results)

    report = {
        "dataset_period": g.dataset_info()["period"],
        "currency": g.dataset_info()["currency"],
        "total_expected_rows": total_expected,
        "total_consumed_rows": total_consumed,
        "total_written_rows": total_written,
        "all_counts_match": all(
            item["count_matches"] for item in results
        ),
        "total_capture_seconds": round(total_seconds, 3),
        "streams": results,
    }

    report_path = OUTPUT_DIR / "capture_audit.json"
    report_path.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )

    print("\n========== FINAL CAPTURE SUMMARY ==========")
    print(json.dumps(report, indent=2))
    print(f"\nAudit report saved to: {report_path.resolve()}")


if __name__ == "__main__":
    main()
