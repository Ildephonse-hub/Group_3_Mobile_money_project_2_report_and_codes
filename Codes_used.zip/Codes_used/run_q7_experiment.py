
from getpass import getpass

import psycopg
from neo4j import GraphDatabase

import compare_section6_q7_experiment as experiment


def main():
    print("Q7 experimental correctness test")
    print("This runs Q7 only: 6 pairs x 2 bounds = 12 cases.\n")

    pg_password = getpass("PostgreSQL password for postgres: ")
    neo_password = getpass("Neo4j password for neo4j: ")

    pg = None
    driver = None

    try:
        pg = psycopg.connect(
            host=experiment.PG_HOST,
            port=experiment.PG_PORT,
            dbname=experiment.PG_DATABASE,
            user=experiment.PG_USER,
            password=pg_password,
            connect_timeout=10,
        )

        driver = GraphDatabase.driver(
            experiment.NEO4J_URI,
            auth=(experiment.NEO4J_USER, neo_password),
        )
        driver.verify_connectivity()

        with driver.session(database=experiment.NEO4J_DATABASE) as neo:
            passed = experiment.compare_q7(pg, neo)

        print("\nExperimental Q7 result:", "PASS" if passed else "FAIL")

    except Exception as exc:
        print(f"\nQ7 experiment failed: {type(exc).__name__}: {exc}")
        raise

    finally:
        if driver is not None:
            driver.close()
        if pg is not None:
            pg.close()
        print("\nDatabase connections closed.")


if __name__ == "__main__":
    main()
