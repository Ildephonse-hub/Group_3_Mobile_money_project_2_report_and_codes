﻿import psycopg
from getpass import getpass

password = getpass("PostgreSQL password: ")

conn = psycopg.connect(
    host="localhost",
    port=5433,
    dbname="mobile_money_investigations",
    user="postgres",
    password=password,
)

sql = """
EXPLAIN (COSTS, VERBOSE, SETTINGS)
WITH RECURSIVE walk(node_type, node_id, depth) AS (
    SELECT 2, 147228, 0
    UNION
    SELECT next_node.node_type, next_node.node_id, w.depth + 1
    FROM walk w
    CROSS JOIN LATERAL (
        SELECT 1 AS node_type, a.customer_id AS node_id
        FROM accounts a
        WHERE w.node_type = 2 AND a.account_id = w.node_id
        UNION
        SELECT 2 AS node_type, a.account_id AS node_id
        FROM accounts a
        WHERE w.node_type = 1 AND a.customer_id = w.node_id
        UNION
        SELECT 3 AS node_type, ad.device_id AS node_id
        FROM account_devices ad
        WHERE w.node_type = 2 AND ad.account_id = w.node_id
        UNION
        SELECT 2 AS node_type, ad.account_id AS node_id
        FROM account_devices ad
        WHERE w.node_type = 3 AND ad.device_id = w.node_id
    ) next_node
    WHERE w.depth < 4
),
reachable AS (
    SELECT DISTINCT node_id AS account_id
    FROM walk
    WHERE node_type = 2 AND depth BETWEEN 1 AND 4
)
SELECT c.region, COUNT(DISTINCT a.account_id)
FROM reachable r
JOIN accounts a ON a.account_id = r.account_id
JOIN customers c ON c.customer_id = a.customer_id
WHERE a.account_id <> 147228
GROUP BY c.region
ORDER BY c.region;
"""

try:
    with conn.cursor() as cur:
        cur.execute(sql)
        for row in cur.fetchall():
            print(row[0])
finally:
    conn.close()
    print("PostgreSQL connection closed.")
