
from getpass import getpass

import psycopg
from neo4j import GraphDatabase

from compare_section6 import (
    PG_HOST, PG_PORT, PG_DATABASE, PG_USER,
    NEO4J_URI, NEO4J_USER, NEO4J_DATABASE,
    CASES, SQL_Q6, CYPHER_Q6, q1_epoch_bounds,
)

pg_password = getpass("PostgreSQL password: ")
neo_password = getpass("Neo4j password: ")

pg = None
driver = None
passed = 0

try:
    pg = psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DATABASE,
        user=PG_USER,
        password=pg_password,
        connect_timeout=10,
    )

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, neo_password),
    )
    driver.verify_connectivity()

    with driver.session(database=NEO4J_DATABASE) as session:
        for case, account, day in CASES:
            start, end = q1_epoch_bounds(day)

            print(f"\n{'=' * 60}")
            print(f"Q6 Case {case} — account {account}")
            print("=" * 60)

            print("Running PostgreSQL...")
            with pg.cursor() as cur:
                cur.execute(SQL_Q6, (account, start, end, end))
                pg_rows = cur.fetchall()

            pg_normalized = sorted(
                [(tuple(row[0]), int(row[1])) for row in pg_rows],
                key=repr,
            )

            print("PostgreSQL sequences:", len(pg_normalized))
            print("Running Neo4j...")

            neo_rows = [
                record.data()
                for record in session.run(
                    CYPHER_Q6,
                    {
                        "account": account,
                        "start_epoch": start,
                        "end_epoch": end,
                    },
                )
            ]

            neo_normalized = sorted(
                [
                    (
                        tuple(row["transfer_ids"]),
                        int(row["transfer_count"]),
                    )
                    for row in neo_rows
                ],
                key=repr,
            )

            ok = pg_normalized == neo_normalized
            print("Neo4j sequences:", len(neo_normalized))
            print("Exact sequence comparison:", "PASS" if ok else "FAIL")

            if not ok:
                print("PostgreSQL:", pg_normalized)
                print("Neo4j:     ", neo_normalized)
            else:
                passed += 1

            for ids, count in pg_normalized:
                print(f"  transfer_ids={ids} | transfer_count={count}")

    print(f"\nQ6 exact comparisons passed: {passed}/6")

finally:
    if pg is not None:
        pg.close()
    if driver is not None:
        driver.close()
    print("Connections closed.")
